package virtualmemory;
import PageReplacement.*;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import javax.swing.JToggleButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JSlider;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import javax.swing.border.EtchedBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.border.SoftBevelBorder;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.LineBorder;
import javax.swing.JCheckBox;

public class Desktop extends JFrame {

	private JPanel contentPane;
	private JTextField txtUser;
	private JTextField textField;
	private JTextField P1page_1;
	private JTextField P1page_2;
	private JTextField P1page_3;
	private JTextField P1page_4;
	private JTextField P1page_5;
	private JTextField P1page_6;
	private JTextField P1page_7;
	private JTextField P1page_8;
	private JTextField P1page_9;
	private JTextField P1page_10;
	private JTextField P2page_1;
	private JTextField P2page_2;
	private JTextField P2page_3;
	private JTextField P2page_4;
	private JTextField P2page_5;
	private JTextField P2page_6;
	private JTextField P2page_7;
	private JTextField P2page_8;
	private JTextField P2page_9;
	private JTextField P2page_10;
	private JTextField P3page_1;
	private JTextField P3page_2;
	private JTextField P3page_3;
	private JTextField P3page_4;
	private JTextField P3page_5;
	private JTextField P3page_6;
	private JTextField P3page_7;
	private JTextField P3page_8;
	private JTextField P3page_9;
	private JTextField P3page_10;
	private JTextField P4page_1;
	private JTextField P4page_2;
	private JTextField P4page_3;
	private JTextField P4page_4;
	private JTextField P4page_5;
	private JTextField P4page_6;
	private JTextField P4page_7;
	private JTextField P4page_8;
	private JTextField P4page_9;
	private JTextField P4page_10;
	private JTextField P5page_1;
	private JTextField P5page_2;
	private JTextField P5page_3;
	private JTextField P5page_4;
	private JTextField P5page_5;
	private JTextField P5page_6;
	private JTextField P5page_7;
	private JTextField P5page_8;
	private JTextField P5page_9;
	private JTextField P5page_10;
	private JLabel Word;
	private JLabel lblWord;
	private JPanel OPTIMALpanel;
	private JPanel LRUpanel;
	private JPanel MFUpanel;
	private JPanel Thrashingpanel;
	private JLabel lblFirefox;
	private JLabel MyDocuments;
	private JLabel lblMyDocuments;
	private JLabel MediaPlayer;
	private JLabel lblMediaPlayer;
	private JLabel lblNinjaCommando;
	private JTextField pagesequence;
	private JButton btnNext;
	JTextField[] page,page1;
	JTextField[] page_optimal,page_lru,page_mfu;
	JPanel panel_11;
	JTextArea textArea;
	JPanel MainMemory;
	protected String pageseq;
	protected String pageseq_optimal,pageseq_lru,pageseq_mfu;
	private JLabel label;
	private JTextField number;
	private JLabel lblSequence;
	private JTextField sequence;
	private JLabel lblExercise;
	private JButton btnStart;
	private JLabel label_1;
	private JPanel panel_12;
	private JLabel label_2;
	private JPanel panel_13;
	JTextArea Fifo_happening;
	private JScrollPane scrollPane_1;
	private JTextField pagflt;
	private JTextField pgflt;
	private JTable table;
	private JTable table_1;
	private JTable table_2;
	private JTable table_3;
	private JTable table_4;
	private JCheckBox chckbxgb;
	private JCheckBox chckbxgb_1;
	private JCheckBox chckbxgb_2;
	private JLabel lblMainMemorySize;
	private JTextField txtOperatingSystem;
	private JPanel panel_14;
	private JSplitPane splitPane_2;
	private JPanel panel_15;
	private JSlider slider_optimal;
	private JLabel label_4;
	private JTextField pagesequence_optimal;
	private JLabel label_5;
	private JPanel panel_16;
	private JLabel label_6;
	private JLabel label_7;
	private JButton buttonGo_optimal;
	private JPanel panel_17;
	private JButton button_1;
	private JLabel label_8;
	private JTextField pgflt_optimal;
	private JPanel panel_18;
	private JLabel label_9;
	private JTextField number_optimal;
	private JLabel label_10;
	private JTextField sequence_optimal;
	private JLabel label_11;
	private JButton button_2;
	private JLabel label_12;
	private JPanel panel_19;
	private JLabel label_13;
	private JPanel panel_20;
	private JLabel label_14;
	private JTextField pagflt_optimal;
	private JPanel panel_21;
	private JPanel panel_22;
	private JSplitPane splitPane_3;
	private JPanel panel_23;
	private JSlider slider_lru;
	private JLabel label_15;
	private JTextField pagesequence_lru;
	private JLabel label_16;
	private JPanel panel_24;
	private JLabel label_17;
	private JLabel label_18;
	private JButton button_3;
	private JPanel panel_25;
	private JButton button_4;
	private JLabel label_19;
	private JTextField pgflt_lru;
	private JPanel panel_26;
	private JLabel label_20;
	private JTextField number_lru;
	private JLabel label_21;
	private JTextField sequence_lru;
	private JLabel label_22;
	private JButton button_5;
	private JLabel label_23;
	private JPanel panel_27;
	private JLabel label_24;
	private JPanel panel_28;
	private JLabel label_25;
	private JTextField pagflt_lru;
	private JPanel panel_29;
	private JPanel panel_30;
	private JSplitPane splitPane_4;
	private JPanel panel_31;
	private JSlider slider_mfu;
	private JLabel label_26;
	private JTextField pagesequence_mfu;
	private JLabel label_27;
	private JPanel panel_32;
	private JLabel label_28;
	private JLabel label_29;
	private JButton button_6;
	private JPanel panel_33;
	private JButton button_7;
	private JLabel label_30;
	private JTextField pgflt_mfu;
	private JPanel panel_34;
	private JLabel label_31;
	private JTextField number_mfu;
	private JLabel label_32;
	private JTextField sequence_mfu;
	private JLabel label_33;
	private JButton button_8;
	private JLabel label_34;
	private JPanel panel_35;
	private JLabel label_35;
	private JPanel panel_36;
	private JLabel label_36;
	private JTextField pagflt_mfu;
	private JPanel panel_37;
	private JTextArea Optimal_happening;
	private JTextArea lru_happening,mfu_happening;
	private JScrollPane scrollPane_2;
	private JScrollPane scrollPane_3;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Desktop frame = new Desktop();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Desktop() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 2000, 1000);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JSplitPane splitPane = new JSplitPane();
		splitPane.setBounds(0, 13, 1950, 930);
		contentPane.add(splitPane);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		splitPane.setRightComponent(tabbedPane);
		splitPane.setDividerLocation(250);
		
		JPanel Backgroundpanel = new JPanel();
		Backgroundpanel.setBackground(new Color(240,240, 240));
		tabbedPane.addTab("Background", null, Backgroundpanel, null);
		Backgroundpanel.setLayout(null);
		
		JLabel lblSystemMode = new JLabel("SYSTEM MODE: ");
		lblSystemMode.setFont(new Font("Rockwell Extra Bold", Font.BOLD | Font.ITALIC, 15));
		lblSystemMode.setBounds(356, 13, 149, 16);
		Backgroundpanel.add(lblSystemMode);
		
		txtUser = new JTextField();
		txtUser.setEditable(false);
		txtUser.setFont(new Font("Rockwell Extra Bold", Font.BOLD | Font.ITALIC, 15));
		txtUser.setText("USER");
		txtUser.setBounds(504, 11, 116, 22);
		Backgroundpanel.add(txtUser);
		txtUser.setColumns(10);
		
		JCheckBox chckbxkb = new JCheckBox("4KB");
		chckbxkb.setBounds(246, 76, 60, 25);
		Backgroundpanel.add(chckbxkb);
		
		JCheckBox chckbxmb = new JCheckBox("8KB");
		chckbxmb.setBounds(317, 76, 113, 25);
		Backgroundpanel.add(chckbxmb);
		
		JLabel lblPageSize = new JLabel("Page Size");
		lblPageSize.setForeground(Color.RED);
		lblPageSize.setBounds(246, 60, 56, 16);
		Backgroundpanel.add(lblPageSize);
		
		JSlider DegreeOfMultiprogrammingslider = new JSlider();
		DegreeOfMultiprogrammingslider.setPaintLabels(true);
		DegreeOfMultiprogrammingslider.setSnapToTicks(true);
		DegreeOfMultiprogrammingslider.setMajorTickSpacing(1);
		DegreeOfMultiprogrammingslider.setMaximum(5);
		DegreeOfMultiprogrammingslider.setMinimum(1);
		DegreeOfMultiprogrammingslider.setPaintTicks(true);
		DegreeOfMultiprogrammingslider.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		DegreeOfMultiprogrammingslider.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Number of Process in Memory", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 69, 0)));
		DegreeOfMultiprogrammingslider.setBounds(459, 60, 233, 61);
		Backgroundpanel.add(DegreeOfMultiprogrammingslider);
		
		chckbxgb = new JCheckBox("1GB");
		chckbxgb.setBounds(12, 76, 56, 25);
		Backgroundpanel.add(chckbxgb);
		
		chckbxgb_1 = new JCheckBox("2GB");
		chckbxgb_1.setBounds(75, 76, 56, 25);
		Backgroundpanel.add(chckbxgb_1);
		
		chckbxgb_2 = new JCheckBox("3GB");
		chckbxgb_2.setBounds(136, 76, 56, 25);
		Backgroundpanel.add(chckbxgb_2);
		
		lblMainMemorySize = new JLabel("Main Memory Size");
		lblMainMemorySize.setForeground(Color.RED);
		lblMainMemorySize.setBounds(12, 60, 132, 16);
		Backgroundpanel.add(lblMainMemorySize);
		
		JButton btnGo_1 = new JButton("GO");
		btnGo_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				bckgnd background = new bckgnd();
				int MM_Size = background.check(chckbxgb,chckbxgb_1,chckbxgb_2);
				int PG_Size = background.getpgsize(chckbxkb,chckbxmb);
				int num_of_process= DegreeOfMultiprogrammingslider.getValue();
				int num_of_frames_per_process = background.find_number_of_frames_for_process(MM_Size,PG_Size,num_of_process,textArea,textField);
				background.initialise(num_of_frames_per_process,num_of_process,MainMemory,P1page_1,P1page_2,P1page_3,P1page_4,P1page_5,P1page_6,P1page_7,P1page_8,P1page_9,P1page_10,
						P2page_1,P2page_2,P2page_3,P2page_4,P2page_5,P2page_6,P2page_7,P2page_8,P2page_9,P2page_10,
						P3page_1,P3page_2,P3page_3,P3page_4,P3page_5,P3page_6,P3page_7,P3page_8,P3page_9,P3page_10,
						P4page_1,P4page_2,P4page_3,P4page_4,P4page_5,P4page_6,P4page_7,P4page_8,P4page_9,P4page_10,
						P5page_1,P5page_2,P5page_3,P5page_4,P5page_5,P5page_6,P5page_7,P5page_8,P5page_9,P5page_10,textArea);
				
				
			}
		});
		btnGo_1.setBounds(427, 422, 97, 25);
		Backgroundpanel.add(btnGo_1);
		MainMemory = new JPanel();
		MainMemory.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		MainMemory.setBounds(12, 159, 680, 232);
		MainMemory.setOpaque(false);
		Backgroundpanel.add(MainMemory);
		MainMemory.setLayout(null);
		
		txtOperatingSystem = new JTextField();
		txtOperatingSystem.setBackground(Color.ORANGE);
		txtOperatingSystem.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		txtOperatingSystem.setHorizontalAlignment(SwingConstants.CENTER);
		txtOperatingSystem.setText("OPERATING SYSTEM");
		txtOperatingSystem.setBounds(12, 13, 180, 206);
		MainMemory.add(txtOperatingSystem);
		txtOperatingSystem.setColumns(10);
		
		JLabel lblNumberOfPage = new JLabel("Number Of Page Frames each process can have:");
		lblNumberOfPage.setForeground(new Color(0, 191, 255));
		lblNumberOfPage.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNumberOfPage.setBounds(12, 426, 321, 16);
		Backgroundpanel.add(lblNumberOfPage);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField.setEditable(false);
		textField.setText("0");
		textField.setBounds(329, 422, 39, 22);
		Backgroundpanel.add(textField);
		textField.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 468, 680, 232);
		Backgroundpanel.add(scrollPane);
		
		JPanel PageTablePanel = new JPanel();
		scrollPane.setViewportView(PageTablePanel);
		PageTablePanel.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		PageTablePanel.setLayout(null);
		
		JLabel lblPageTables = new JLabel("Page Tables:");
		lblPageTables.setForeground(new Color(0, 128, 128));
		lblPageTables.setBounds(12, 13, 100, 26);
		PageTablePanel.add(lblPageTables);
		
		table = new JTable();
		table.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"   PTE 1"},
				{"   PTE 2"},
				{"   PTE 3"},
				{"   PTE 4"},
				{"   PTE 5"},
				{"   PTE 6"},
				{"   PTE 7"},
				{"   PTE 8"},
				{"   PTE 9"},
				{"   PTE 10"},
			},
			new String[] {
				"Process 1 Page table"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table.setColumnSelectionAllowed(true);
		table.setBounds(12, 52, 90, 168);
		PageTablePanel.add(table);
		
		table_1 = new JTable();
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
				{"   PTE 1"},
				{"   PTE 2"},
				{"   PTE 3"},
				{"   PTE 4"},
				{"   PTE 5"},
				{"   PTE 6"},
				{"   PTE 7"},
				{"   PTE 8"},
				{"   PTE 9"},
				{"   PTE 10"},
			},
			new String[] {
				"New column"
			}
		));
		table_1.setColumnSelectionAllowed(true);
		table_1.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		table_1.setBounds(138, 52, 90, 168);
		PageTablePanel.add(table_1);
		
		table_2 = new JTable();
		table_2.setModel(new DefaultTableModel(
			new Object[][] {
				{"   PTE 1"},
				{"   PTE 2"},
				{"   PTE 3"},
				{"   PTE 4"},
				{"   PTE 5"},
				{"   PTE 6"},
				{"   PTE 7"},
				{"   PTE 8"},
				{"   PTE 9"},
				{"   PTE 10"},
			},
			new String[] {
				"New column"
			}
		));
		table_2.setColumnSelectionAllowed(true);
		table_2.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		table_2.setBounds(273, 52, 90, 168);
		PageTablePanel.add(table_2);
		
		table_3 = new JTable();
		table_3.setModel(new DefaultTableModel(
			new Object[][] {
				{"   PTE 1"},
				{"   PTE 2"},
				{"   PTE 3"},
				{"   PTE 4"},
				{"   PTE 5"},
				{"   PTE 6"},
				{"   PTE 7"},
				{"   PTE 8"},
				{"   PTE 9"},
				{"   PTE 10"},
			},
			new String[] {
				"New column"
			}
		));
		table_3.setColumnSelectionAllowed(true);
		table_3.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		table_3.setBounds(414, 52, 90, 168);
		PageTablePanel.add(table_3);
		
		table_4 = new JTable();
		table_4.setModel(new DefaultTableModel(
			new Object[][] {
				{"   PTE 1"},
				{"   PTE 2"},
				{"   PTE 3"},
				{"   PTE 4"},
				{"   PTE 5"},
				{"   PTE 6"},
				{"   PTE 7"},
				{"   PTE 8"},
				{"   PTE 9"},
				{"   PTE 10"},
			},
			new String[] {
				"New column"
			}
		));
		table_4.setColumnSelectionAllowed(true);
		table_4.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		table_4.setBounds(531, 52, 90, 168);
		PageTablePanel.add(table_4);
		
		JPanel OperatingSystemPanel = new JPanel();
		OperatingSystemPanel.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		OperatingSystemPanel.setBounds(75, 743, 567, 110);
		Backgroundpanel.add(OperatingSystemPanel);
		OperatingSystemPanel.setLayout(null);
		
		JLabel lblOperatingSystem = new JLabel("Translation Lookaside Buffer (TLB)");
		lblOperatingSystem.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		lblOperatingSystem.setForeground(new Color(128, 0, 0));
		lblOperatingSystem.setBounds(50, 40, 517, 31);
		OperatingSystemPanel.add(lblOperatingSystem);
		
		JPanel VirtualMemoryPanel = new JPanel();
		VirtualMemoryPanel.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		VirtualMemoryPanel.setBounds(767, 145, 442, 708);
		Backgroundpanel.add(VirtualMemoryPanel);
		VirtualMemoryPanel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_1.setBounds(12, 27, 418, 97);
		VirtualMemoryPanel.add(panel_1);
		panel_1.setLayout(null);
		
		P1page_1 = new JTextField();
		P1page_1.setBackground(Color.GREEN);
		P1page_1.setHorizontalAlignment(SwingConstants.CENTER);
		P1page_1.setText("P1-1");
		P1page_1.setBounds(12, 15, 69, 22);
		panel_1.add(P1page_1);
		P1page_1.setColumns(10);
		
		P1page_2 = new JTextField();
		P1page_2.setBackground(Color.GREEN);
		P1page_2.setText("P1-2");
		P1page_2.setHorizontalAlignment(SwingConstants.CENTER);
		P1page_2.setColumns(10);
		P1page_2.setBounds(93, 13, 69, 22);
		panel_1.add(P1page_2);
		
		P1page_3 = new JTextField();
		P1page_3.setBackground(Color.GREEN);
		P1page_3.setText("P1-3");
		P1page_3.setHorizontalAlignment(SwingConstants.CENTER);
		P1page_3.setColumns(10);
		P1page_3.setBounds(174, 13, 69, 22);
		panel_1.add(P1page_3);
		
		P1page_4 = new JTextField();
		P1page_4.setBackground(Color.GREEN);
		P1page_4.setText("P1-4");
		P1page_4.setHorizontalAlignment(SwingConstants.CENTER);
		P1page_4.setColumns(10);
		P1page_4.setBounds(255, 13, 69, 22);
		panel_1.add(P1page_4);
		
		P1page_5 = new JTextField();
		P1page_5.setBackground(Color.GREEN);
		P1page_5.setText("P1-5");
		P1page_5.setHorizontalAlignment(SwingConstants.CENTER);
		P1page_5.setColumns(10);
		P1page_5.setBounds(336, 13, 69, 22);
		panel_1.add(P1page_5);
		
		P1page_6 = new JTextField();
		P1page_6.setBackground(Color.GREEN);
		P1page_6.setText("P1-6");
		P1page_6.setHorizontalAlignment(SwingConstants.CENTER);
		P1page_6.setColumns(10);
		P1page_6.setBounds(12, 62, 69, 22);
		panel_1.add(P1page_6);
		
		P1page_7 = new JTextField();
		P1page_7.setBackground(Color.GREEN);
		P1page_7.setText("P1-7");
		P1page_7.setHorizontalAlignment(SwingConstants.CENTER);
		P1page_7.setColumns(10);
		P1page_7.setBounds(93, 62, 69, 22);
		panel_1.add(P1page_7);
		
		P1page_8 = new JTextField();
		P1page_8.setBackground(Color.GREEN);
		P1page_8.setText("P1-8");
		P1page_8.setHorizontalAlignment(SwingConstants.CENTER);
		P1page_8.setColumns(10);
		P1page_8.setBounds(174, 62, 69, 22);
		panel_1.add(P1page_8);
		
		P1page_9 = new JTextField();
		P1page_9.setBackground(Color.GREEN);
		P1page_9.setText("P1-9");
		P1page_9.setHorizontalAlignment(SwingConstants.CENTER);
		P1page_9.setColumns(10);
		P1page_9.setBounds(255, 62, 69, 22);
		panel_1.add(P1page_9);
		
		P1page_10 = new JTextField();
		P1page_10.setBackground(Color.GREEN);
		P1page_10.setText("P1-10");
		P1page_10.setHorizontalAlignment(SwingConstants.CENTER);
		P1page_10.setColumns(10);
		P1page_10.setBounds(336, 62, 69, 22);
		panel_1.add(P1page_10);
		
		JLabel lblProcess = new JLabel("Process 1");
		lblProcess.setForeground(Color.BLACK);
		lblProcess.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblProcess.setHorizontalAlignment(SwingConstants.CENTER);
		lblProcess.setBounds(12, 13, 71, 16);
		VirtualMemoryPanel.add(lblProcess);
		
		JLabel lblProcess_4 = new JLabel("Process 2");
		lblProcess_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblProcess_4.setForeground(Color.BLACK);
		lblProcess_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblProcess_4.setBounds(12, 149, 71, 16);
		VirtualMemoryPanel.add(lblProcess_4);
		
		JLabel lblProcess_3 = new JLabel("Process 3");
		lblProcess_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblProcess_3.setForeground(Color.BLACK);
		lblProcess_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblProcess_3.setBounds(12, 299, 71, 16);
		VirtualMemoryPanel.add(lblProcess_3);
		
		JLabel lblProcess_2 = new JLabel("Process 4");
		lblProcess_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblProcess_2.setForeground(Color.BLACK);
		lblProcess_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblProcess_2.setBounds(12, 451, 71, 16);
		VirtualMemoryPanel.add(lblProcess_2);
		
		JLabel lblProcess_1 = new JLabel("Process 5");
		lblProcess_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblProcess_1.setForeground(Color.BLACK);
		lblProcess_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblProcess_1.setBounds(12, 577, 71, 16);
		VirtualMemoryPanel.add(lblProcess_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_2.setBackground(Color.WHITE);
		panel_2.setBounds(12, 170, 418, 97);
		VirtualMemoryPanel.add(panel_2);
		
		P2page_1 = new JTextField();
		P2page_1.setText("P2-1");
		P2page_1.setHorizontalAlignment(SwingConstants.CENTER);
		P2page_1.setColumns(10);
		P2page_1.setBackground(Color.GREEN);
		P2page_1.setBounds(12, 14, 69, 22);
		panel_2.add(P2page_1);
		
		P2page_2 = new JTextField();
		P2page_2.setText("P2-2");
		P2page_2.setHorizontalAlignment(SwingConstants.CENTER);
		P2page_2.setColumns(10);
		P2page_2.setBackground(Color.GREEN);
		P2page_2.setBounds(93, 13, 69, 22);
		panel_2.add(P2page_2);
		
		P2page_3 = new JTextField();
		P2page_3.setText("P2-3");
		P2page_3.setHorizontalAlignment(SwingConstants.CENTER);
		P2page_3.setColumns(10);
		P2page_3.setBackground(Color.GREEN);
		P2page_3.setBounds(174, 13, 69, 22);
		panel_2.add(P2page_3);
		
		P2page_4 = new JTextField();
		P2page_4.setText("P2-4");
		P2page_4.setHorizontalAlignment(SwingConstants.CENTER);
		P2page_4.setColumns(10);
		P2page_4.setBackground(Color.GREEN);
		P2page_4.setBounds(255, 13, 69, 22);
		panel_2.add(P2page_4);
		
		P2page_5 = new JTextField();
		P2page_5.setText("P2-5");
		P2page_5.setHorizontalAlignment(SwingConstants.CENTER);
		P2page_5.setColumns(10);
		P2page_5.setBackground(Color.GREEN);
		P2page_5.setBounds(336, 13, 69, 22);
		panel_2.add(P2page_5);
		
		P2page_6 = new JTextField();
		P2page_6.setText("P2-6");
		P2page_6.setHorizontalAlignment(SwingConstants.CENTER);
		P2page_6.setColumns(10);
		P2page_6.setBackground(Color.GREEN);
		P2page_6.setBounds(12, 62, 69, 22);
		panel_2.add(P2page_6);
		
		P2page_7 = new JTextField();
		P2page_7.setText("P2-7");
		P2page_7.setHorizontalAlignment(SwingConstants.CENTER);
		P2page_7.setColumns(10);
		P2page_7.setBackground(Color.GREEN);
		P2page_7.setBounds(93, 62, 69, 22);
		panel_2.add(P2page_7);
		
		P2page_8 = new JTextField();
		P2page_8.setText("P2-8");
		P2page_8.setHorizontalAlignment(SwingConstants.CENTER);
		P2page_8.setColumns(10);
		P2page_8.setBackground(Color.GREEN);
		P2page_8.setBounds(174, 62, 69, 22);
		panel_2.add(P2page_8);
		
		P2page_9 = new JTextField();
		P2page_9.setText("P2-9");
		P2page_9.setHorizontalAlignment(SwingConstants.CENTER);
		P2page_9.setColumns(10);
		P2page_9.setBackground(Color.GREEN);
		P2page_9.setBounds(255, 62, 69, 22);
		panel_2.add(P2page_9);
		
		P2page_10 = new JTextField();
		P2page_10.setText("P2-10");
		P2page_10.setHorizontalAlignment(SwingConstants.CENTER);
		P2page_10.setColumns(10);
		P2page_10.setBackground(Color.GREEN);
		P2page_10.setBounds(336, 62, 69, 22);
		panel_2.add(P2page_10);
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_3.setBackground(Color.WHITE);
		panel_3.setBounds(12, 321, 418, 97);
		VirtualMemoryPanel.add(panel_3);
		
		P3page_1 = new JTextField();
		P3page_1.setText("P3-1");
		P3page_1.setHorizontalAlignment(SwingConstants.CENTER);
		P3page_1.setColumns(10);
		P3page_1.setBackground(Color.GREEN);
		P3page_1.setBounds(12, 13, 69, 22);
		panel_3.add(P3page_1);
		
		P3page_2 = new JTextField();
		P3page_2.setText("P3-2");
		P3page_2.setHorizontalAlignment(SwingConstants.CENTER);
		P3page_2.setColumns(10);
		P3page_2.setBackground(Color.GREEN);
		P3page_2.setBounds(93, 13, 69, 22);
		panel_3.add(P3page_2);
		
		P3page_3 = new JTextField();
		P3page_3.setText("P3-3");
		P3page_3.setHorizontalAlignment(SwingConstants.CENTER);
		P3page_3.setColumns(10);
		P3page_3.setBackground(Color.GREEN);
		P3page_3.setBounds(174, 13, 69, 22);
		panel_3.add(P3page_3);
		
		P3page_4 = new JTextField();
		P3page_4.setText("P3-4");
		P3page_4.setHorizontalAlignment(SwingConstants.CENTER);
		P3page_4.setColumns(10);
		P3page_4.setBackground(Color.GREEN);
		P3page_4.setBounds(255, 13, 69, 22);
		panel_3.add(P3page_4);
		
		P3page_5 = new JTextField();
		P3page_5.setText("P3-5");
		P3page_5.setHorizontalAlignment(SwingConstants.CENTER);
		P3page_5.setColumns(10);
		P3page_5.setBackground(Color.GREEN);
		P3page_5.setBounds(336, 13, 69, 22);
		panel_3.add(P3page_5);
		
		P3page_6 = new JTextField();
		P3page_6.setText("P3-6");
		P3page_6.setHorizontalAlignment(SwingConstants.CENTER);
		P3page_6.setColumns(10);
		P3page_6.setBackground(Color.GREEN);
		P3page_6.setBounds(12, 62, 69, 22);
		panel_3.add(P3page_6);
		
		P3page_7 = new JTextField();
		P3page_7.setText("P3-7");
		P3page_7.setHorizontalAlignment(SwingConstants.CENTER);
		P3page_7.setColumns(10);
		P3page_7.setBackground(Color.GREEN);
		P3page_7.setBounds(93, 62, 69, 22);
		panel_3.add(P3page_7);
		
		P3page_8 = new JTextField();
		P3page_8.setText("P3-8");
		P3page_8.setHorizontalAlignment(SwingConstants.CENTER);
		P3page_8.setColumns(10);
		P3page_8.setBackground(Color.GREEN);
		P3page_8.setBounds(174, 62, 69, 22);
		panel_3.add(P3page_8);
		
		P3page_9 = new JTextField();
		P3page_9.setText("P3-9");
		P3page_9.setHorizontalAlignment(SwingConstants.CENTER);
		P3page_9.setColumns(10);
		P3page_9.setBackground(Color.GREEN);
		P3page_9.setBounds(255, 62, 69, 22);
		panel_3.add(P3page_9);
		
		P3page_10 = new JTextField();
		P3page_10.setText("P3-10");
		P3page_10.setHorizontalAlignment(SwingConstants.CENTER);
		P3page_10.setColumns(10);
		P3page_10.setBackground(Color.GREEN);
		P3page_10.setBounds(336, 62, 69, 22);
		panel_3.add(P3page_10);
		
		JPanel panel_4 = new JPanel();
		panel_4.setLayout(null);
		panel_4.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_4.setBackground(Color.WHITE);
		panel_4.setBounds(12, 467, 418, 97);
		VirtualMemoryPanel.add(panel_4);
		
		P4page_1 = new JTextField();
		P4page_1.setText("P4-1");
		P4page_1.setHorizontalAlignment(SwingConstants.CENTER);
		P4page_1.setColumns(10);
		P4page_1.setBackground(Color.GREEN);
		P4page_1.setBounds(12, 13, 69, 22);
		panel_4.add(P4page_1);
		
		P4page_2 = new JTextField();
		P4page_2.setText("P4-2");
		P4page_2.setHorizontalAlignment(SwingConstants.CENTER);
		P4page_2.setColumns(10);
		P4page_2.setBackground(Color.GREEN);
		P4page_2.setBounds(93, 13, 69, 22);
		panel_4.add(P4page_2);
		
		P4page_3 = new JTextField();
		P4page_3.setText("P4-3");
		P4page_3.setHorizontalAlignment(SwingConstants.CENTER);
		P4page_3.setColumns(10);
		P4page_3.setBackground(Color.GREEN);
		P4page_3.setBounds(174, 13, 69, 22);
		panel_4.add(P4page_3);
		
		P4page_4 = new JTextField();
		P4page_4.setText("P4-4");
		P4page_4.setHorizontalAlignment(SwingConstants.CENTER);
		P4page_4.setColumns(10);
		P4page_4.setBackground(Color.GREEN);
		P4page_4.setBounds(255, 13, 69, 22);
		panel_4.add(P4page_4);
		
		P4page_5 = new JTextField();
		P4page_5.setText("P4-5");
		P4page_5.setHorizontalAlignment(SwingConstants.CENTER);
		P4page_5.setColumns(10);
		P4page_5.setBackground(Color.GREEN);
		P4page_5.setBounds(336, 13, 69, 22);
		panel_4.add(P4page_5);
		
		P4page_6 = new JTextField();
		P4page_6.setText("P4-6");
		P4page_6.setHorizontalAlignment(SwingConstants.CENTER);
		P4page_6.setColumns(10);
		P4page_6.setBackground(Color.GREEN);
		P4page_6.setBounds(12, 62, 69, 22);
		panel_4.add(P4page_6);
		
		P4page_7 = new JTextField();
		P4page_7.setText("P4-7");
		P4page_7.setHorizontalAlignment(SwingConstants.CENTER);
		P4page_7.setColumns(10);
		P4page_7.setBackground(Color.GREEN);
		P4page_7.setBounds(93, 62, 69, 22);
		panel_4.add(P4page_7);
		
		P4page_8 = new JTextField();
		P4page_8.setText("P4-8");
		P4page_8.setHorizontalAlignment(SwingConstants.CENTER);
		P4page_8.setColumns(10);
		P4page_8.setBackground(Color.GREEN);
		P4page_8.setBounds(174, 62, 69, 22);
		panel_4.add(P4page_8);
		
		P4page_9 = new JTextField();
		P4page_9.setText("P4-9");
		P4page_9.setHorizontalAlignment(SwingConstants.CENTER);
		P4page_9.setColumns(10);
		P4page_9.setBackground(Color.GREEN);
		P4page_9.setBounds(255, 62, 69, 22);
		panel_4.add(P4page_9);
		
		P4page_10 = new JTextField();
		P4page_10.setText("P4-10");
		P4page_10.setHorizontalAlignment(SwingConstants.CENTER);
		P4page_10.setColumns(10);
		P4page_10.setBackground(Color.GREEN);
		P4page_10.setBounds(336, 62, 69, 22);
		panel_4.add(P4page_10);
		
		JPanel panel_5 = new JPanel();
		panel_5.setLayout(null);
		panel_5.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_5.setBackground(Color.WHITE);
		panel_5.setBounds(12, 598, 418, 97);
		VirtualMemoryPanel.add(panel_5);
		
		P5page_1 = new JTextField();
		P5page_1.setText("P5-1");
		P5page_1.setHorizontalAlignment(SwingConstants.CENTER);
		P5page_1.setColumns(10);
		P5page_1.setBackground(Color.GREEN);
		P5page_1.setBounds(12, 13, 69, 22);
		panel_5.add(P5page_1);
		
		P5page_2 = new JTextField();
		P5page_2.setText("P5-2");
		P5page_2.setHorizontalAlignment(SwingConstants.CENTER);
		P5page_2.setColumns(10);
		P5page_2.setBackground(Color.GREEN);
		P5page_2.setBounds(93, 13, 69, 22);
		panel_5.add(P5page_2);
		
		P5page_3 = new JTextField();
		P5page_3.setText("P5-3");
		P5page_3.setHorizontalAlignment(SwingConstants.CENTER);
		P5page_3.setColumns(10);
		P5page_3.setBackground(Color.GREEN);
		P5page_3.setBounds(174, 13, 69, 22);
		panel_5.add(P5page_3);
		
		P5page_4 = new JTextField();
		P5page_4.setText("P5-4");
		P5page_4.setHorizontalAlignment(SwingConstants.CENTER);
		P5page_4.setColumns(10);
		P5page_4.setBackground(Color.GREEN);
		P5page_4.setBounds(255, 13, 69, 22);
		panel_5.add(P5page_4);
		
		P5page_5 = new JTextField();
		P5page_5.setText("P5-5");
		P5page_5.setHorizontalAlignment(SwingConstants.CENTER);
		P5page_5.setColumns(10);
		P5page_5.setBackground(Color.GREEN);
		P5page_5.setBounds(336, 13, 69, 22);
		panel_5.add(P5page_5);
		
		P5page_6 = new JTextField();
		P5page_6.setText("P5-6");
		P5page_6.setHorizontalAlignment(SwingConstants.CENTER);
		P5page_6.setColumns(10);
		P5page_6.setBackground(Color.GREEN);
		P5page_6.setBounds(12, 62, 69, 22);
		panel_5.add(P5page_6);
		
		P5page_7 = new JTextField();
		P5page_7.setText("P5-7");
		P5page_7.setHorizontalAlignment(SwingConstants.CENTER);
		P5page_7.setColumns(10);
		P5page_7.setBackground(Color.GREEN);
		P5page_7.setBounds(93, 62, 69, 22);
		panel_5.add(P5page_7);
		
		P5page_8 = new JTextField();
		P5page_8.setText("P5-8");
		P5page_8.setHorizontalAlignment(SwingConstants.CENTER);
		P5page_8.setColumns(10);
		P5page_8.setBackground(Color.GREEN);
		P5page_8.setBounds(174, 62, 69, 22);
		panel_5.add(P5page_8);
		
		P5page_9 = new JTextField();
		P5page_9.setText("P5-9");
		P5page_9.setHorizontalAlignment(SwingConstants.CENTER);
		P5page_9.setColumns(10);
		P5page_9.setBackground(Color.GREEN);
		P5page_9.setBounds(255, 62, 69, 22);
		panel_5.add(P5page_9);
		
		P5page_10 = new JTextField();
		P5page_10.setText("P5-10");
		P5page_10.setHorizontalAlignment(SwingConstants.CENTER);
		P5page_10.setColumns(10);
		P5page_10.setBackground(Color.GREEN);
		P5page_10.setBounds(336, 62, 69, 22);
		panel_5.add(P5page_10);
		
		JLabel lblVirtualMemory = new JLabel("Virtual Memory:");
		lblVirtualMemory.setForeground(new Color(255, 165, 0));
		lblVirtualMemory.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		lblVirtualMemory.setBounds(767, 116, 180, 28);
		Backgroundpanel.add(lblVirtualMemory);
		
		JLabel lblMainMemory = new JLabel("Main Memory:");
		lblMainMemory.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		lblMainMemory.setForeground(new Color(72, 209, 204));
		lblMainMemory.setBounds(12, 116, 163, 24);
		Backgroundpanel.add(lblMainMemory);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_6.setBounds(1262, 145, 343, 708);
		Backgroundpanel.add(panel_6);
		panel_6.setLayout(null);
		
		textArea = new JTextArea();
		textArea.setFont(new Font("Monospaced", Font.BOLD, 15));
		textArea.setForeground(Color.RED);
		textArea.setLineWrap(true);
		textArea.setBounds(12, 13, 319, 682);
		panel_6.add(textArea);
		
		JLabel lblWhatsHappening = new JLabel("What's Happening??");
		lblWhatsHappening.setForeground(new Color(255, 0, 0));
		lblWhatsHappening.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		lblWhatsHappening.setHorizontalAlignment(SwingConstants.CENTER);
		lblWhatsHappening.setBounds(1324, 104, 180, 28);
		Backgroundpanel.add(lblWhatsHappening);		
		
		JButton btnNext_1 = new JButton("NEXT");
		btnNext_1.setBounds(549, 422, 97, 25);
		Backgroundpanel.add(btnNext_1);
		
		
		
		
		
		JPanel FIFOpanel = new JPanel();
		tabbedPane.addTab("FIFO", null, FIFOpanel, null);
		FIFOpanel.setLayout(null);
		
		JSplitPane splitPane_1 = new JSplitPane();
		splitPane_1.setBounds(12, 13, 1305, 872);
		FIFOpanel.add(splitPane_1);
		
		JPanel panel_7 = new JPanel();
		panel_7.setOpaque(false);
		splitPane_1.setLeftComponent(panel_7);
		panel_7.setLayout(null);
		
		JSlider slider = new JSlider();
		slider.setBounds(364, 24, 200, 50);
		slider.setSnapToTicks(true);
		slider.setPaintLabels(true);
		slider.setPaintTicks(true);
		slider.setForeground(new Color(0, 0, 153));
		slider.setMajorTickSpacing(1);
		slider.setMinimum(1);
		slider.setMaximum(9);
		panel_7.add(slider);
		
		JLabel lblNumberOfFrames = new JLabel("Number of frames that can fit in Main Memory:");
		lblNumberOfFrames.setBounds(12, 13, 354, 50);
		lblNumberOfFrames.setForeground(new Color(153, 51, 255));
		lblNumberOfFrames.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblNumberOfFrames.setHorizontalAlignment(SwingConstants.CENTER);
		panel_7.add(lblNumberOfFrames);
		
		pagesequence = new JTextField();
		pagesequence.setBounds(33, 191, 342, 32);
		panel_7.add(pagesequence);
		pagesequence.setColumns(10);
		
		JLabel lblEnterThePage = new JLabel("Enter The Page Sequence Here:");
		lblEnterThePage.setBounds(23, 152, 240, 26);
		lblEnterThePage.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblEnterThePage.setForeground(new Color(255, 102, 102));
		lblEnterThePage.setHorizontalAlignment(SwingConstants.CENTER);
		panel_7.add(lblEnterThePage);
		
		JPanel panel_10 = new JPanel();
		panel_10.setBounds(23, 332, 603, 111);
		panel_10.setOpaque(false);
		panel_10.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_7.add(panel_10);
		panel_10.setLayout(null);
		
		JLabel lblMainMemory_1 = new JLabel("Main Memory:");
		lblMainMemory_1.setBounds(23, 295, 132, 26);
		lblMainMemory_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		lblMainMemory_1.setForeground(new Color(153, 51, 204));
		lblMainMemory_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel_7.add(lblMainMemory_1);
		
		JLabel lblVirtualMemory_1 = new JLabel("Virtual Memory:");
		lblVirtualMemory_1.setBounds(28, 488, 149, 16);
		lblVirtualMemory_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		lblVirtualMemory_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblVirtualMemory_1.setForeground(new Color(204, 153, 51));
		panel_7.add(lblVirtualMemory_1);
		
		
		
		JButton btnGo = new JButton("GO");
		btnGo.setBounds(437, 191, 109, 32);
		btnGo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Fifo_happening.setText(null);
				pageseq = pagesequence.getText();
				int numofpages_to_be_created = maxofseq(pageseq);
				page= new JTextField[numofpages_to_be_created+1];
				int k = 12,y=13;
				for(int i=0;i<numofpages_to_be_created+1;i++)
				{	
					page[i]= new JTextField();
					page[i].setText(Integer.toString(i));
					page[i].setEditable(false);
					page[i].setBackground(Color.CYAN);
					if(i<5){
					page[i].setBounds(k, y, 40, 80);
					}else if(i<6){
						y= y+100;
						k = k-(120*5);
						page[i].setBounds(k, y, 40, 80);
					} else{
						page[i].setBounds(k, y, 40, 80);
					}
					
					
					panel_11.add(page[i]);
					k+=120;					
				}
				
			}
		});
		btnGo.setForeground(new Color(51, 51, 204));
		panel_7.add(btnGo);
		
		panel_11 = new JPanel();
		panel_11.setBounds(23, 511, 603, 223);
		panel_7.add(panel_11);
		panel_11.setOpaque(false);
		panel_11.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_11.setLayout(null);
		
		btnNext = new JButton("NEXT");
		btnNext.setBounds(166, 774, 228, 37);
		btnNext.addActionListener(new ActionListener() {
			int currentframe=0;
			public void actionPerformed(ActionEvent e) {
				if(currentframe<pageseq.length()){
					int numberofframes = slider.getValue();
					FIFO fifo = new FIFO();
					int[] converted = fifo.Convert(pageseq);
					int L = converted[currentframe];
					int g = fifo.framecheck(L,numberofframes,pgflt);
					if(g==1)
					{
						fifo.move_into_memory(L, page,panel_10);
						Fifo_happening.setForeground(new Color(0,255,0));
						Fifo_happening.append("\n-> According to the algorithm the page "+L+" has to be moved into memory.\n ");
						
					}else if (g==2){
						fifo.replace_pagein_memory_fifo(L, page,panel_10);
						Fifo_happening.setForeground(new Color(0,255,0));
						Fifo_happening.append("\n-> According to the algorithm the page in memory has to be replaced with page "+L+"\n");
					}else if(g==0){
						Fifo_happening.setForeground(new Color(0,255,0));
						Fifo_happening.append("\n-> The page is already present in memory.\n");
					}
					currentframe+=1;
				}
			}
		});
		Image next = new ImageIcon(this.getClass().getResource("/Next-icon.png")).getImage();
		btnNext.setIcon(new ImageIcon(next));
		btnNext.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		btnNext.setForeground(new Color(0, 102, 153));
		panel_7.add(btnNext);
		
		JLabel label_3 = new JLabel("Page Faults:");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setForeground(new Color(139, 69, 19));
		label_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		label_3.setBounds(12, 254, 132, 29);
		panel_7.add(label_3);
		
		pgflt = new JTextField();
		pgflt.setBackground(new Color(0, 0, 0));
		pgflt.setForeground(new Color(255, 99, 71));
		pgflt.setText("0");
		pgflt.setHorizontalAlignment(SwingConstants.CENTER);
		pgflt.setEditable(false);
		pgflt.setColumns(10);
		pgflt.setBounds(130, 258, 35, 22);
		panel_7.add(pgflt);
		
		JPanel panel_8 = new JPanel();
		splitPane_1.setRightComponent(panel_8);
		panel_8.setLayout(null);
		
		label = new JLabel("Number of frames that can fit in Main Memory:");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(new Color(153, 51, 255));
		label.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label.setBounds(12, 83, 354, 50);
		panel_8.add(label);
		
		number = new JTextField();
		number.setForeground(new Color(255, 51, 51));
		number.setHorizontalAlignment(SwingConstants.CENTER);
		number.setEditable(false);
		number.setBounds(365, 98, 116, 22);
		panel_8.add(number);
		number.setColumns(10);
		
		lblSequence = new JLabel("SEQUENCE:");
		lblSequence.setHorizontalAlignment(SwingConstants.CENTER);
		lblSequence.setForeground(new Color(255, 102, 102));
		lblSequence.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblSequence.setBounds(-25, 158, 174, 32);
		panel_8.add(lblSequence);
		
		sequence = new JTextField();
		sequence.setEditable(false);
		sequence.setBounds(119, 164, 305, 22);
		panel_8.add(sequence);
		sequence.setColumns(10);
		
		lblExercise = new JLabel("EXERCISE");
		lblExercise.setForeground(new Color(102, 51, 102));
		lblExercise.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		lblExercise.setHorizontalAlignment(SwingConstants.CENTER);
		lblExercise.setBounds(242, 13, 206, 32);
		panel_8.add(lblExercise);
		
		btnStart = new JButton("START");
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Random random = new Random();
				int numofpgs = random.nextInt(9);
				while(numofpgs==0){numofpgs=random.nextInt(9);}
				number.setText(Integer.toString(numofpgs));
				int[] seq = new int[15];
				String sequ =Integer.toString(random.nextInt(9));
				for(int i=0;i<14;i++)
				{
					seq[i]= random.nextInt(9);
					sequ = sequ+Integer.toString(seq[i]);
				}
				sequence.setText(sequ);
				FIFO fifo1 = new FIFO();
				fifo1.pages(panel_13,panel_12,numofpgs,sequ,Fifo_happening,pagflt);
				fifo1.work(numofpgs,sequ,panel_12);
			}
		});
		btnStart.setBackground(new Color(51, 0, 0));
		btnStart.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 17));
		btnStart.setForeground(new Color(204, 51, 51));
		btnStart.setBounds(484, 163, 97, 25);
		panel_8.add(btnStart);
		
		label_1 = new JLabel("Main Memory:");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setForeground(new Color(153, 51, 204));
		label_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_1.setBounds(12, 297, 132, 26);
		panel_8.add(label_1);
		
		panel_12 = new JPanel();
		panel_12.setLayout(null);
		panel_12.setOpaque(false);
		panel_12.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_12.setBounds(12, 334, 603, 111);
		panel_8.add(panel_12);
		
		label_2 = new JLabel("Virtual Memory:");
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setForeground(new Color(204, 153, 51));
		label_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_2.setBounds(17, 490, 149, 16);
		panel_8.add(label_2);
		
		panel_13 = new JPanel();
		
		panel_13.setLayout(null);
		panel_13.setOpaque(false);
		panel_13.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_13.setBounds(12, 513, 603, 223);
		panel_8.add(panel_13);
		
		JLabel lblPageFaults = new JLabel("Page Faults:");
		lblPageFaults.setForeground(new Color(139, 69, 19));
		lblPageFaults.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblPageFaults.setHorizontalAlignment(SwingConstants.CENTER);
		lblPageFaults.setBounds(17, 255, 132, 29);
		panel_8.add(lblPageFaults);
		
		pagflt = new JTextField();
		pagflt.setForeground(new Color(255, 99, 71));
		pagflt.setBackground(new Color(0, 0, 0));
		pagflt.setEditable(false);
		pagflt.setHorizontalAlignment(SwingConstants.CENTER);
		pagflt.setText("0");
		pagflt.setBounds(135, 259, 35, 22);
		panel_8.add(pagflt);
		pagflt.setColumns(10);
		
		
		
		splitPane_1.setDividerLocation(650);
		
		JPanel panel_9 = new JPanel();
		panel_9.setLayout(null);
		panel_9.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_9.setBounds(1347, 46, 302, 839);
		FIFOpanel.add(panel_9);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(12, 13, 279, 813);
		panel_9.add(scrollPane_1);
		
		Fifo_happening = new JTextArea();
		Fifo_happening.setLineWrap(true);
		Fifo_happening.setFont(new Font("Monospaced", Font.BOLD, 13));
		scrollPane_1.setViewportView(Fifo_happening);
		
		OPTIMALpanel = new JPanel();
		tabbedPane.addTab("OPTIMAL", null, OPTIMALpanel, null);
		OPTIMALpanel.setLayout(null);
		
		panel_14 = new JPanel();
		panel_14.setLayout(null);
		panel_14.setBounds(0, 0, 1689, 894);
		OPTIMALpanel.add(panel_14);
		
		splitPane_2 = new JSplitPane();
		splitPane_2.setBounds(12, 13, 1305, 872);
		panel_14.add(splitPane_2);
		
		panel_15 = new JPanel();
		panel_15.setLayout(null);
		panel_15.setOpaque(false);
		splitPane_2.setLeftComponent(panel_15);
		
		slider_optimal = new JSlider();
		slider_optimal.setSnapToTicks(true);
		slider_optimal.setPaintTicks(true);
		slider_optimal.setPaintLabels(true);
		slider_optimal.setMinimum(1);
		slider_optimal.setMaximum(9);
		slider_optimal.setMajorTickSpacing(1);
		slider_optimal.setForeground(new Color(0, 0, 153));
		slider_optimal.setBounds(364, 24, 200, 50);
		panel_15.add(slider_optimal);
		
		label_4 = new JLabel("Number of frames that can fit in Main Memory:");
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setForeground(new Color(153, 51, 255));
		label_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label_4.setBounds(12, 13, 354, 50);
		panel_15.add(label_4);
		
		pagesequence_optimal = new JTextField();
		pagesequence_optimal.setColumns(10);
		pagesequence_optimal.setBounds(33, 191, 342, 32);
		panel_15.add(pagesequence_optimal);
		
		label_5 = new JLabel("Enter The Page Sequence Here:");
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setForeground(new Color(255, 102, 102));
		label_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label_5.setBounds(23, 152, 240, 26);
		panel_15.add(label_5);
		
		panel_16 = new JPanel();
		panel_16.setOpaque(false);
		panel_16.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_16.setBounds(23, 332, 603, 111);
		panel_15.add(panel_16);
		panel_16.setLayout(null);
		
		label_6 = new JLabel("Main Memory:");
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setForeground(new Color(153, 51, 204));
		label_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_6.setBounds(23, 295, 132, 26);
		panel_15.add(label_6);
		
		label_7 = new JLabel("Virtual Memory:");
		label_7.setHorizontalAlignment(SwingConstants.CENTER);
		label_7.setForeground(new Color(204, 153, 51));
		label_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_7.setBounds(28, 488, 149, 16);
		panel_15.add(label_7);
		
		buttonGo_optimal = new JButton("GO");
		buttonGo_optimal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Optimal_happening.setText(null);
				pageseq_optimal = pagesequence_optimal.getText();
				int numofpages_to_be_created = maxofseq(pageseq_optimal);
				page_optimal = new JTextField[numofpages_to_be_created+1];
				int k = 12,y=13;
				for(int i=0;i<numofpages_to_be_created+1;i++)
				{	
					page_optimal[i]= new JTextField();
					page_optimal[i].setText(Integer.toString(i));
					page_optimal[i].setEditable(false);
					page_optimal[i].setBackground(Color.CYAN);
					if(i<5){
						page_optimal[i].setBounds(k, y, 40, 80);
					}else if(i<6){
						y= y+100;
						k = k-(120*5);
						page_optimal[i].setBounds(k, y, 40, 80);
					} else{
						page_optimal[i].setBounds(k, y, 40, 80);
					}
					
					
					panel_17.add(page_optimal[i]);
					k+=120;					
				}
				
			}
		});
		buttonGo_optimal.setForeground(new Color(51, 51, 204));
		buttonGo_optimal.setBounds(437, 191, 109, 32);
		panel_15.add(buttonGo_optimal);
		
		panel_17 = new JPanel();
		panel_17.setOpaque(false);
		panel_17.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_17.setBounds(23, 511, 603, 223);
		panel_15.add(panel_17);
		panel_17.setLayout(null);
		
		button_1 = new JButton("NEXT");
		button_1.addActionListener(new ActionListener() {
			int currentframe_optimal=0;
			public void actionPerformed(ActionEvent e) {
				if(currentframe_optimal<pageseq_optimal.length()){
					int numberofframes_optimal = slider_optimal.getValue();
					OPTIMAL optimal = new OPTIMAL();
					int[] converted_optimal = optimal.Convert(pageseq_optimal);
					int A = converted_optimal[currentframe_optimal];
					int V = optimal.framecheck_optimal(A, numberofframes_optimal,pgflt_optimal);
					
					if( V==1)
					{
						optimal.move_into_memory_optimal(A,page_optimal,panel_16);
						Optimal_happening.setForeground(new Color(0,255,0));
						Optimal_happening.append("\n-> According to the algorithm the page"+ A+" has to moved into memory");
					}
					if(V==2)
					{
						optimal.replace_page_in_memory_optimal(A,page_optimal,panel_16,currentframe_optimal,converted_optimal);
						Optimal_happening.setForeground(new Color(0,255,0));
						Optimal_happening.append("\n-> According to the algorithm the page"+ A+" has to replaced into memory");
					}
					else if(V==0)
					{
						Optimal_happening.setForeground(new Color(0,255,0));
						Optimal_happening.append("\n-> Page is already in memory");
					}
					currentframe_optimal++;
				}
				
			}
		});
		button_1.setForeground(new Color(0, 102, 153));
		button_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		button_1.setBounds(166, 774, 228, 37);
		panel_15.add(button_1);
		
		label_8 = new JLabel("Page Faults:");
		label_8.setHorizontalAlignment(SwingConstants.CENTER);
		label_8.setForeground(new Color(139, 69, 19));
		label_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		label_8.setBounds(12, 254, 132, 29);
		panel_15.add(label_8);
		
		pgflt_optimal = new JTextField();
		pgflt_optimal.setText("0");
		pgflt_optimal.setHorizontalAlignment(SwingConstants.CENTER);
		pgflt_optimal.setForeground(new Color(255, 99, 71));
		pgflt_optimal.setEditable(false);
		pgflt_optimal.setColumns(10);
		pgflt_optimal.setBackground(Color.BLACK);
		pgflt_optimal.setBounds(130, 258, 35, 22);
		panel_15.add(pgflt_optimal);
		
		panel_18 = new JPanel();
		panel_18.setLayout(null);
		splitPane_2.setRightComponent(panel_18);
		
		label_9 = new JLabel("Number of frames that can fit in Main Memory:");
		label_9.setHorizontalAlignment(SwingConstants.CENTER);
		label_9.setForeground(new Color(153, 51, 255));
		label_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label_9.setBounds(12, 83, 354, 50);
		panel_18.add(label_9);
		
		number_optimal = new JTextField();
		number_optimal.setHorizontalAlignment(SwingConstants.CENTER);
		number_optimal.setForeground(new Color(255, 51, 51));
		number_optimal.setEditable(false);
		number_optimal.setColumns(10);
		number_optimal.setBounds(365, 98, 116, 22);
		panel_18.add(number_optimal);
		
		label_10 = new JLabel("SEQUENCE:");
		label_10.setHorizontalAlignment(SwingConstants.CENTER);
		label_10.setForeground(new Color(255, 102, 102));
		label_10.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label_10.setBounds(-25, 158, 174, 32);
		panel_18.add(label_10);
		
		sequence_optimal = new JTextField();
		sequence_optimal.setEditable(false);
		sequence_optimal.setColumns(10);
		sequence_optimal.setBounds(119, 164, 305, 22);
		panel_18.add(sequence_optimal);
		
		label_11 = new JLabel("EXERCISE");
		label_11.setHorizontalAlignment(SwingConstants.CENTER);
		label_11.setForeground(new Color(102, 51, 102));
		label_11.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		label_11.setBounds(242, 13, 206, 32);
		panel_18.add(label_11);
		
		button_2 = new JButton("START");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Random random = new Random();
				int numofpgs = random.nextInt(9);
				while(numofpgs==0){numofpgs=random.nextInt(9);}
				number_optimal.setText(Integer.toString(numofpgs));
				int[] seq = new int[15];
				String sequ =Integer.toString(random.nextInt(9));
				for(int i=0;i<14;i++)
				{
					seq[i]= random.nextInt(9);
					sequ = sequ+Integer.toString(seq[i]);
				}
				sequence_optimal.setText(sequ);
				
				OPTIMAL optimal1 = new OPTIMAL();
				optimal1.pages(panel_20,panel_19,numofpgs,sequ,Optimal_happening,pagflt_optimal,seq);
				optimal1.work(numofpgs, sequ, panel_19);
				
			}
		});
		button_2.setForeground(new Color(204, 51, 51));
		button_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 17));
		button_2.setBackground(new Color(51, 0, 0));
		button_2.setBounds(484, 163, 97, 25);
		panel_18.add(button_2);
		
		label_12 = new JLabel("Main Memory:");
		label_12.setHorizontalAlignment(SwingConstants.CENTER);
		label_12.setForeground(new Color(153, 51, 204));
		label_12.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_12.setBounds(12, 297, 132, 26);
		panel_18.add(label_12);
		
		panel_19 = new JPanel();
		panel_19.setOpaque(false);
		panel_19.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_19.setBounds(12, 334, 603, 111);
		panel_18.add(panel_19);
		panel_19.setLayout(null);
		
		label_13 = new JLabel("Virtual Memory:");
		label_13.setHorizontalAlignment(SwingConstants.CENTER);
		label_13.setForeground(new Color(204, 153, 51));
		label_13.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_13.setBounds(17, 490, 149, 16);
		panel_18.add(label_13);
		
		panel_20 = new JPanel();
		panel_20.setOpaque(false);
		panel_20.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_20.setBounds(12, 513, 603, 223);
		panel_18.add(panel_20);
		panel_20.setLayout(null);
		
		label_14 = new JLabel("Page Faults:");
		label_14.setHorizontalAlignment(SwingConstants.CENTER);
		label_14.setForeground(new Color(139, 69, 19));
		label_14.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		label_14.setBounds(17, 255, 132, 29);
		panel_18.add(label_14);
		
		pagflt_optimal = new JTextField();
		pagflt_optimal.setText("0");
		pagflt_optimal.setHorizontalAlignment(SwingConstants.CENTER);
		pagflt_optimal.setForeground(new Color(255, 99, 71));
		pagflt_optimal.setEditable(false);
		pagflt_optimal.setColumns(10);
		pagflt_optimal.setBackground(Color.BLACK);
		pagflt_optimal.setBounds(135, 259, 35, 22);
		panel_18.add(pagflt_optimal);
		splitPane_2.setDividerLocation(650);
		
		panel_21 = new JPanel();
		panel_21.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_21.setBounds(1347, 46, 302, 839);
		panel_14.add(panel_21);
		panel_21.setLayout(null);
		
		scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(15, 16, 277, 811);
		panel_21.add(scrollPane_2);
		
		Optimal_happening = new JTextArea();
		scrollPane_2.setViewportView(Optimal_happening);
		Optimal_happening.setLineWrap(true);
		Optimal_happening.setFont(new Font("Monospaced", Font.BOLD, 13));
		
		
		LRUpanel = new JPanel();
		tabbedPane.addTab("LRU", null, LRUpanel, null);
		LRUpanel.setLayout(null);
		
		panel_22 = new JPanel();
		panel_22.setLayout(null);
		panel_22.setBounds(0, 0, 1689, 894);
		LRUpanel.add(panel_22);
		
		splitPane_3 = new JSplitPane();
		splitPane_3.setBounds(12, 13, 1305, 872);
		panel_22.add(splitPane_3);
		
		panel_23 = new JPanel();
		panel_23.setLayout(null);
		panel_23.setOpaque(false);
		splitPane_3.setLeftComponent(panel_23);
		
		slider_lru = new JSlider();
		slider_lru.setSnapToTicks(true);
		slider_lru.setPaintTicks(true);
		slider_lru.setPaintLabels(true);
		slider_lru.setMinimum(1);
		slider_lru.setMaximum(9);
		slider_lru.setMajorTickSpacing(1);
		slider_lru.setForeground(new Color(0, 0, 153));
		slider_lru.setBounds(364, 24, 200, 50);
		panel_23.add(slider_lru);
		
		label_15 = new JLabel("Number of frames that can fit in Main Memory:");
		label_15.setHorizontalAlignment(SwingConstants.CENTER);
		label_15.setForeground(new Color(153, 51, 255));
		label_15.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label_15.setBounds(12, 13, 354, 50);
		panel_23.add(label_15);
		
		pagesequence_lru = new JTextField();
		pagesequence_lru.setColumns(10);
		pagesequence_lru.setBounds(33, 191, 342, 32);
		panel_23.add(pagesequence_lru);
		
		label_16 = new JLabel("Enter The Page Sequence Here:");
		label_16.setHorizontalAlignment(SwingConstants.CENTER);
		label_16.setForeground(new Color(255, 102, 102));
		label_16.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label_16.setBounds(23, 152, 240, 26);
		panel_23.add(label_16);
		
		panel_24 = new JPanel();
		panel_24.setLayout(null);
		panel_24.setOpaque(false);
		panel_24.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_24.setBounds(23, 332, 603, 111);
		panel_23.add(panel_24);
		
		label_17 = new JLabel("Main Memory:");
		label_17.setHorizontalAlignment(SwingConstants.CENTER);
		label_17.setForeground(new Color(153, 51, 204));
		label_17.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_17.setBounds(23, 295, 132, 26);
		panel_23.add(label_17);
		
		label_18 = new JLabel("Virtual Memory:");
		label_18.setHorizontalAlignment(SwingConstants.CENTER);
		label_18.setForeground(new Color(204, 153, 51));
		label_18.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_18.setBounds(28, 488, 149, 16);
		panel_23.add(label_18);
		
		button_3 = new JButton("GO");
		button_3.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				

				lru_happening.setText(null);
				pageseq_lru = pagesequence_lru.getText();
				int numofpages_to_be_created_lru = maxofseq(pageseq_lru);
				page_lru= new JTextField[numofpages_to_be_created_lru+1];
				int k = 12,y=13;
				for(int i=0;i<numofpages_to_be_created_lru+1;i++)
				{	
					page_lru[i]= new JTextField();
					page_lru[i].setText(Integer.toString(i));
					page_lru[i].setEditable(false);
					page_lru[i].setBackground(Color.CYAN);
					if(i<5){
					page_lru[i].setBounds(k, y, 40, 80);
					}else if(i<6){
						y= y+100;
						k = k-(120*5);
						page_lru[i].setBounds(k, y, 40, 80);
					} else{
						page_lru[i].setBounds(k, y, 40, 80);
					}
					
					
					panel_25.add(page_lru[i]);
					k+=120;					
				}
				
			
			}
		});
		button_3.setForeground(new Color(51, 51, 204));
		button_3.setBounds(437, 191, 109, 32);
		panel_23.add(button_3);
		
		panel_25 = new JPanel();
		panel_25.setLayout(null);
		panel_25.setOpaque(false);
		panel_25.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_25.setBounds(23, 511, 603, 223);
		panel_23.add(panel_25);
		
		button_4 = new JButton("NEXT");
		button_4.addActionListener(new ActionListener() {
			int currentframe_lru=0;
			public void actionPerformed(ActionEvent e) {
				
				int number_of_frames_lru = slider_lru.getValue();
				LRU lru = new LRU();
				int[] converted_lru = lru.Convert(pageseq_lru);
				int L = converted_lru[currentframe_lru];
				int K = lru.framecheck_lru(L,number_of_frames_lru,pgflt_lru);
				
				if( K==1)
				{
					lru.move_into_memory_lru(L,page_lru,panel_24);
					lru_happening.setForeground(new Color(0,255,0));
					lru_happening.append("\n-> According to the algorithm the page"+ L+" has to moved into memory");
				}
				if(K==2)
				{
					lru.replace_page_in_memory_lru(L,page_lru,panel_24,currentframe_lru,converted_lru);
					lru_happening.setForeground(new Color(0,255,0));
					lru_happening.append("\n-> According to the algorithm the page"+ L+" has to replaced into memory");
				}
				else if(K==0)
				{
					lru_happening.setForeground(new Color(0,255,0));
					lru_happening.append("\n-> Page is already in memory");
				}
				currentframe_lru++;
				
				
				
			}
		});
		button_4.setForeground(new Color(0, 102, 153));
		button_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		button_4.setBounds(166, 774, 228, 37);
		panel_23.add(button_4);
		
		label_19 = new JLabel("Page Faults:");
		label_19.setHorizontalAlignment(SwingConstants.CENTER);
		label_19.setForeground(new Color(139, 69, 19));
		label_19.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		label_19.setBounds(12, 254, 132, 29);
		panel_23.add(label_19);
		
		pgflt_lru = new JTextField();
		pgflt_lru.setText("0");
		pgflt_lru.setHorizontalAlignment(SwingConstants.CENTER);
		pgflt_lru.setForeground(new Color(255, 99, 71));
		pgflt_lru.setEditable(false);
		pgflt_lru.setColumns(10);
		pgflt_lru.setBackground(Color.BLACK);
		pgflt_lru.setBounds(130, 258, 35, 22);
		panel_23.add(pgflt_lru);
		
		panel_26 = new JPanel();
		panel_26.setLayout(null);
		splitPane_3.setRightComponent(panel_26);
		
		label_20 = new JLabel("Number of frames that can fit in Main Memory:");
		label_20.setHorizontalAlignment(SwingConstants.CENTER);
		label_20.setForeground(new Color(153, 51, 255));
		label_20.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label_20.setBounds(12, 83, 354, 50);
		panel_26.add(label_20);
		
		number_lru = new JTextField();
		number_lru.setHorizontalAlignment(SwingConstants.CENTER);
		number_lru.setForeground(new Color(255, 51, 51));
		number_lru.setEditable(false);
		number_lru.setColumns(10);
		number_lru.setBounds(365, 98, 116, 22);
		panel_26.add(number_lru);
		
		label_21 = new JLabel("SEQUENCE:");
		label_21.setHorizontalAlignment(SwingConstants.CENTER);
		label_21.setForeground(new Color(255, 102, 102));
		label_21.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label_21.setBounds(-25, 158, 174, 32);
		panel_26.add(label_21);
		
		sequence_lru = new JTextField();
		sequence_lru.setEditable(false);
		sequence_lru.setColumns(10);
		sequence_lru.setBounds(119, 164, 305, 22);
		panel_26.add(sequence_lru);
		
		label_22 = new JLabel("EXERCISE");
		label_22.setHorizontalAlignment(SwingConstants.CENTER);
		label_22.setForeground(new Color(102, 51, 102));
		label_22.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		label_22.setBounds(242, 13, 206, 32);
		panel_26.add(label_22);
		
		button_5 = new JButton("START");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

				Random random = new Random();
				int numofpgs = random.nextInt(9);
				while(numofpgs==0){numofpgs=random.nextInt(9);}
				number_lru.setText(Integer.toString(numofpgs));
				int[] seq = new int[15];
				String sequ =Integer.toString(random.nextInt(9));
				for(int i=0;i<14;i++)
				{
					seq[i]= random.nextInt(9);
					sequ = sequ+Integer.toString(seq[i]);
				}
				sequence_lru.setText(sequ);
				
				LRU lru1 = new LRU();
				lru1.pages(panel_28,panel_27,numofpgs,sequ,lru_happening,pagflt_lru,seq);
				lru1.work(numofpgs, sequ, panel_27);
				
			
			}
		});
		button_5.setForeground(new Color(204, 51, 51));
		button_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 17));
		button_5.setBackground(new Color(51, 0, 0));
		button_5.setBounds(484, 163, 97, 25);
		panel_26.add(button_5);
		
		label_23 = new JLabel("Main Memory:");
		label_23.setHorizontalAlignment(SwingConstants.CENTER);
		label_23.setForeground(new Color(153, 51, 204));
		label_23.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_23.setBounds(12, 297, 132, 26);
		panel_26.add(label_23);
		
		panel_27 = new JPanel();
		panel_27.setLayout(null);
		panel_27.setOpaque(false);
		panel_27.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_27.setBounds(12, 334, 603, 111);
		panel_26.add(panel_27);
		
		label_24 = new JLabel("Virtual Memory:");
		label_24.setHorizontalAlignment(SwingConstants.CENTER);
		label_24.setForeground(new Color(204, 153, 51));
		label_24.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_24.setBounds(17, 490, 149, 16);
		panel_26.add(label_24);
		
		panel_28 = new JPanel();
		panel_28.setLayout(null);
		panel_28.setOpaque(false);
		panel_28.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_28.setBounds(12, 513, 603, 223);
		panel_26.add(panel_28);
		
		label_25 = new JLabel("Page Faults:");
		label_25.setHorizontalAlignment(SwingConstants.CENTER);
		label_25.setForeground(new Color(139, 69, 19));
		label_25.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		label_25.setBounds(17, 255, 132, 29);
		panel_26.add(label_25);
		
		pagflt_lru = new JTextField();
		pagflt_lru.setText("0");
		pagflt_lru.setHorizontalAlignment(SwingConstants.CENTER);
		pagflt_lru.setForeground(new Color(255, 99, 71));
		pagflt_lru.setEditable(false);
		pagflt_lru.setColumns(10);
		pagflt_lru.setBackground(Color.BLACK);
		pagflt_lru.setBounds(135, 259, 35, 22);
		panel_26.add(pagflt_lru);
		splitPane_3.setDividerLocation(650);
		
		panel_29 = new JPanel();
		panel_29.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_29.setBounds(1347, 46, 302, 839);
		panel_22.add(panel_29);
		panel_29.setLayout(null);
		
		scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(15, 16, 272, 807);
		panel_29.add(scrollPane_3);
		
		lru_happening = new JTextArea();
		scrollPane_3.setViewportView(lru_happening);		
		lru_happening.setLineWrap(true);
		lru_happening.setFont(new Font("Monospaced", Font.BOLD, 13));
		
		MFUpanel = new JPanel();
		tabbedPane.addTab("MFU", null, MFUpanel, null);
		MFUpanel.setLayout(null);
		
		panel_30 = new JPanel();
		panel_30.setLayout(null);
		panel_30.setBounds(0, 0, 1689, 894);
		MFUpanel.add(panel_30);
		
		splitPane_4 = new JSplitPane();
		splitPane_4.setBounds(12, 13, 1305, 872);
		panel_30.add(splitPane_4);
		
		panel_31 = new JPanel();
		panel_31.setLayout(null);
		panel_31.setOpaque(false);
		splitPane_4.setLeftComponent(panel_31);
		
		slider_mfu = new JSlider();
		slider_mfu.setSnapToTicks(true);
		slider_mfu.setPaintTicks(true);
		slider_mfu.setPaintLabels(true);
		slider_mfu.setMinimum(1);
		slider_mfu.setMaximum(9);
		slider_mfu.setMajorTickSpacing(1);
		slider_mfu.setForeground(new Color(0, 0, 153));
		slider_mfu.setBounds(364, 24, 200, 50);
		panel_31.add(slider_mfu);
		
		label_26 = new JLabel("Number of frames that can fit in Main Memory:");
		label_26.setHorizontalAlignment(SwingConstants.CENTER);
		label_26.setForeground(new Color(153, 51, 255));
		label_26.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label_26.setBounds(12, 13, 354, 50);
		panel_31.add(label_26);
		
		pagesequence_mfu = new JTextField();
		pagesequence_mfu.setColumns(10);
		pagesequence_mfu.setBounds(33, 191, 342, 32);
		panel_31.add(pagesequence_mfu);
		
		label_27 = new JLabel("Enter The Page Sequence Here:");
		label_27.setHorizontalAlignment(SwingConstants.CENTER);
		label_27.setForeground(new Color(255, 102, 102));
		label_27.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label_27.setBounds(23, 152, 240, 26);
		panel_31.add(label_27);
		
		panel_32 = new JPanel();
		panel_32.setLayout(null);
		panel_32.setOpaque(false);
		panel_32.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_32.setBounds(23, 332, 603, 111);
		panel_31.add(panel_32);
		
		label_28 = new JLabel("Main Memory:");
		label_28.setHorizontalAlignment(SwingConstants.CENTER);
		label_28.setForeground(new Color(153, 51, 204));
		label_28.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_28.setBounds(23, 295, 132, 26);
		panel_31.add(label_28);
		
		label_29 = new JLabel("Virtual Memory:");
		label_29.setHorizontalAlignment(SwingConstants.CENTER);
		label_29.setForeground(new Color(204, 153, 51));
		label_29.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_29.setBounds(28, 488, 149, 16);
		panel_31.add(label_29);
		
		button_6 = new JButton("GO");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				
				mfu_happening.setText(null);
				pageseq_mfu = pagesequence_mfu.getText();
				int numofpages_to_be_created = maxofseq(pageseq_mfu);
				page_mfu = new JTextField[numofpages_to_be_created+1];
				int k = 12,y=13;
				for(int i=0;i<numofpages_to_be_created+1;i++)
				{	
					page_mfu[i]= new JTextField();
					page_mfu[i].setText(Integer.toString(i));
					page_mfu[i].setEditable(false);
					page_mfu[i].setBackground(Color.CYAN);
					if(i<5){
						page_mfu[i].setBounds(k, y, 40, 80);
					}else if(i<6){
						y= y+100;
						k = k-(120*5);
						page_mfu[i].setBounds(k, y, 40, 80);
					} else{
						page_mfu[i].setBounds(k, y, 40, 80);
					}
					
					
					panel_33.add(page_mfu[i]);
					k+=120;					
				}
				
			
			}
		});
		button_6.setForeground(new Color(51, 51, 204));
		button_6.setBounds(437, 191, 109, 32);
		panel_31.add(button_6);
		
		panel_33 = new JPanel();
		panel_33.setLayout(null);
		panel_33.setOpaque(false);
		panel_33.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_33.setBounds(23, 511, 603, 223);
		panel_31.add(panel_33);
		
		button_7 = new JButton("NEXT");
		button_7.addActionListener(new ActionListener() {
			int currentframe_mfu =0;
			public void actionPerformed(ActionEvent arg0) {

				
				int number_of_frames_mfu = slider_mfu.getValue();
				MFU mfu = new MFU();
				int[] converted_mfu = mfu.Convert(pageseq_mfu);
				int L = converted_mfu[currentframe_mfu];
				int K = mfu.framecheck_mfu(L,number_of_frames_mfu,pgflt_mfu);
				
				if( K==1)
				{
					mfu.move_into_memory_mfu(L,page_mfu,panel_32);
					mfu_happening.setForeground(new Color(0,255,0));
					mfu_happening.append("\n-> According to the algorithm the page"+ L+" has to moved into memory");
				}
				if(K==2)
				{
					mfu.replace_page_in_memory_mfu(L,page_mfu,panel_32,currentframe_mfu,converted_mfu);
					mfu_happening.setForeground(new Color(0,255,0));
					mfu_happening.append("\n-> According to the algorithm the page"+ L+" has to replaced into memory");
				}
				else if(K==0)
				{
					mfu_happening.setForeground(new Color(0,255,0));
					mfu_happening.append("\n-> Page is already in memory");
				}
				currentframe_mfu++;
				
				
				
			
			}
		});
		button_7.setForeground(new Color(0, 102, 153));
		button_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		button_7.setBounds(166, 774, 228, 37);
		panel_31.add(button_7);
		
		label_30 = new JLabel("Page Faults:");
		label_30.setHorizontalAlignment(SwingConstants.CENTER);
		label_30.setForeground(new Color(139, 69, 19));
		label_30.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		label_30.setBounds(12, 254, 132, 29);
		panel_31.add(label_30);
		
		pgflt_mfu = new JTextField();
		pgflt_mfu.setText("0");
		pgflt_mfu.setHorizontalAlignment(SwingConstants.CENTER);
		pgflt_mfu.setForeground(new Color(255, 99, 71));
		pgflt_mfu.setEditable(false);
		pgflt_mfu.setColumns(10);
		pgflt_mfu.setBackground(Color.BLACK);
		pgflt_mfu.setBounds(130, 258, 35, 22);
		panel_31.add(pgflt_mfu);
		
		panel_34 = new JPanel();
		panel_34.setLayout(null);
		splitPane_4.setRightComponent(panel_34);
		
		label_31 = new JLabel("Number of frames that can fit in Main Memory:");
		label_31.setHorizontalAlignment(SwingConstants.CENTER);
		label_31.setForeground(new Color(153, 51, 255));
		label_31.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label_31.setBounds(12, 83, 354, 50);
		panel_34.add(label_31);
		
		number_mfu = new JTextField();
		number_mfu.setHorizontalAlignment(SwingConstants.CENTER);
		number_mfu.setForeground(new Color(255, 51, 51));
		number_mfu.setEditable(false);
		number_mfu.setColumns(10);
		number_mfu.setBounds(365, 98, 116, 22);
		panel_34.add(number_mfu);
		
		label_32 = new JLabel("SEQUENCE:");
		label_32.setHorizontalAlignment(SwingConstants.CENTER);
		label_32.setForeground(new Color(255, 102, 102));
		label_32.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		label_32.setBounds(-25, 158, 174, 32);
		panel_34.add(label_32);
		
		sequence_mfu = new JTextField();
		sequence_mfu.setEditable(false);
		sequence_mfu.setColumns(10);
		sequence_mfu.setBounds(119, 164, 305, 22);
		panel_34.add(sequence_mfu);
		
		label_33 = new JLabel("EXERCISE");
		label_33.setHorizontalAlignment(SwingConstants.CENTER);
		label_33.setForeground(new Color(102, 51, 102));
		label_33.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		label_33.setBounds(242, 13, 206, 32);
		panel_34.add(label_33);
		
		button_8 = new JButton("START");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				

				Random random = new Random();
				int numofpgs = random.nextInt(9);
				while(numofpgs==0){numofpgs=random.nextInt(9);}
				number_mfu.setText(Integer.toString(numofpgs));
				int[] seq = new int[15];
				String sequ =Integer.toString(random.nextInt(9));
				for(int i=0;i<14;i++)
				{
					seq[i]= random.nextInt(9);
					sequ = sequ+Integer.toString(seq[i]);
				}
				sequence_mfu.setText(sequ);
				
				MFU mfu1 = new MFU();
				mfu1.pages(panel_36,panel_35,numofpgs,sequ,mfu_happening,pagflt_mfu,seq);
				mfu1.work(numofpgs, sequ, panel_35);
				
			
			
			}
		});
		button_8.setForeground(new Color(204, 51, 51));
		button_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 17));
		button_8.setBackground(new Color(51, 0, 0));
		button_8.setBounds(484, 163, 97, 25);
		panel_34.add(button_8);
		
		label_34 = new JLabel("Main Memory:");
		label_34.setHorizontalAlignment(SwingConstants.CENTER);
		label_34.setForeground(new Color(153, 51, 204));
		label_34.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_34.setBounds(12, 297, 132, 26);
		panel_34.add(label_34);
		
		panel_35 = new JPanel();
		panel_35.setLayout(null);
		panel_35.setOpaque(false);
		panel_35.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_35.setBounds(12, 334, 603, 111);
		panel_34.add(panel_35);
		
		label_35 = new JLabel("Virtual Memory:");
		label_35.setHorizontalAlignment(SwingConstants.CENTER);
		label_35.setForeground(new Color(204, 153, 51));
		label_35.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		label_35.setBounds(17, 490, 149, 16);
		panel_34.add(label_35);
		
		panel_36 = new JPanel();
		panel_36.setLayout(null);
		panel_36.setOpaque(false);
		panel_36.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_36.setBounds(12, 513, 603, 223);
		panel_34.add(panel_36);
		
		label_36 = new JLabel("Page Faults:");
		label_36.setHorizontalAlignment(SwingConstants.CENTER);
		label_36.setForeground(new Color(139, 69, 19));
		label_36.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		label_36.setBounds(17, 255, 132, 29);
		panel_34.add(label_36);
		
		pagflt_mfu = new JTextField();
		pagflt_mfu.setText("0");
		pagflt_mfu.setHorizontalAlignment(SwingConstants.CENTER);
		pagflt_mfu.setForeground(new Color(255, 99, 71));
		pagflt_mfu.setEditable(false);
		pagflt_mfu.setColumns(10);
		pagflt_mfu.setBackground(Color.BLACK);
		pagflt_mfu.setBounds(135, 259, 35, 22);
		panel_34.add(pagflt_mfu);
		splitPane_4.setDividerLocation(650);
		
		panel_37 = new JPanel();
		panel_37.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.RAISED, null, null, null, null)));
		panel_37.setBounds(1347, 46, 302, 839);
		panel_30.add(panel_37);
		panel_37.setLayout(null);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(15, 16, 272, 807);
		panel_37.add(scrollPane_4);
		
		mfu_happening = new JTextArea();
		scrollPane_4.setViewportView(mfu_happening);
		mfu_happening.setLineWrap(true);
		mfu_happening.setFont(new Font("Monospaced", Font.BOLD, 13));
		
		Thrashingpanel = new JPanel();
		tabbedPane.addTab("Thrashing", null, Thrashingpanel, null);
		
		JPanel VPAT = new JPanel();
		tabbedPane.addTab("Virtual to Physical Address transaltion", null, VPAT, null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 0));
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		splitPane.setLeftComponent(panel);
		panel.setBounds(100, 100, 100, 100);
		panel.setLayout(null);
		
		Word = new JLabel("");
		Word.setBounds(24, 34, 88, 87);
		Image WordImg = new ImageIcon(this.getClass().getResource("/Word-icon.png")).getImage();
		Word.setIcon(new ImageIcon(WordImg));
		panel.add(Word);
		
		lblWord = new JLabel("WORD");
		lblWord.setForeground(new Color(255, 255, 255));
		lblWord.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		lblWord.setHorizontalAlignment(SwingConstants.CENTER);
		lblWord.setBounds(24, 123, 56, 29);
		panel.add(lblWord);
		
		JLabel Firefox = new JLabel("");
		Image firefox = new ImageIcon(this.getClass().getResource("/Firefox-icon.png")).getImage();
		Firefox.setIcon(new ImageIcon(firefox));
		Firefox.setBounds(24, 207, 76, 66);
		panel.add(Firefox);
		
		lblFirefox = new JLabel("FIREFOX");
		lblFirefox.setForeground(new Color(255, 255, 255));
		lblFirefox.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		lblFirefox.setHorizontalAlignment(SwingConstants.CENTER);
		lblFirefox.setBounds(24, 286, 76, 16);
		panel.add(lblFirefox);
		
		MyDocuments = new JLabel("");
		Image mydocs = new ImageIcon(this.getClass().getResource("/My-documents-icon.png")).getImage();
		MyDocuments.setIcon(new ImageIcon(mydocs));
		MyDocuments.setBounds(24, 372, 76, 73);
		panel.add(MyDocuments);
		
		lblMyDocuments = new JLabel("My Documents");
		lblMyDocuments.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		lblMyDocuments.setForeground(new Color(255, 255, 255));
		lblMyDocuments.setBounds(12, 458, 139, 29);
		panel.add(lblMyDocuments);
		
		MediaPlayer = new JLabel("");
		Image mediaplayer = new ImageIcon(this.getClass().getResource("/mediaplayer-icon.png")).getImage();
		MediaPlayer.setIcon(new ImageIcon(mediaplayer));
		MediaPlayer.setBounds(24, 549, 76, 73);
		panel.add(MediaPlayer);
		
		lblMediaPlayer = new JLabel("MEDIA PLAYER");
		lblMediaPlayer.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		lblMediaPlayer.setForeground(new Color(255, 255, 255));
		lblMediaPlayer.setHorizontalAlignment(SwingConstants.CENTER);
		lblMediaPlayer.setBounds(12, 635, 139, 16);
		panel.add(lblMediaPlayer);
		
		JLabel game = new JLabel("");
		Image gameimg = new ImageIcon(this.getClass().getResource("/ninjacommando-icon.png")).getImage();
		game.setIcon(new ImageIcon(gameimg));
		game.setBounds(24, 717, 105, 66);
		panel.add(game);
		
		lblNinjaCommando = new JLabel("Ninja Commando");
		lblNinjaCommando.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		lblNinjaCommando.setForeground(new Color(255, 255, 255));
		lblNinjaCommando.setBounds(24, 796, 151, 32);
		panel.add(lblNinjaCommando);
		
		
	}
public int maxofseq (String seq){
		
		int[] Converted = new int[seq.length()];
		for(int i=0;i<seq.length();i++){
			Converted[i]= Integer.parseInt(seq.substring(i, i+1));			
		}
		Arrays.sort(Converted);
		int k = Converted[Converted.length-1];
		
		return k;
		
	}
}
