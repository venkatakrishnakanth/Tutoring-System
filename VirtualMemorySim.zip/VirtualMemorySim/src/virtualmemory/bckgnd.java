package virtualmemory;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Rectangle;

import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import AppPackage.AnimationClass;

public class bckgnd {
	
	JTextField[] mem_pages;
	
	
public int check(JCheckBox box1,JCheckBox box2,JCheckBox box3)
{
	if(box1.isSelected())
	{
		box2.setSelected(false);
		box3.setSelected(false);
		box2.setEnabled(false);
		box3.setEnabled(false);
		return 1;
	}
	if(box2.isSelected())
	{
		box1.setSelected(false);
		box3.setSelected(false);
		box1.setEnabled(false);
		box3.setEnabled(false);
		return 2;
	}
	if(box3.isSelected())
	{
		box2.setSelected(false);
		box1.setSelected(false);
		box2.setEnabled(false);
		box1.setEnabled(false);
		return 3;
	}
	return 0;
}

public int getpgsize(JCheckBox box1, JCheckBox box2) {
	
	if(box1.isSelected())
	{
		box2.setSelected(false);		
		box2.setEnabled(false);		
		return 1;
	}
	if(box2.isSelected())
	{
		box1.setSelected(false);		
		box1.setEnabled(false);		
		return 1;
	}
	
	return 0;
}

public int find_number_of_frames_for_process(int MM_Size, int PG_Size, int num_of_process,JTextArea txtArea,JTextField textField) {
	
	
	if(MM_Size==0||PG_Size==0)
	{
		txtArea.append("\nPlease select main memory size and page size and press GO");
		return 0;
	}
	
	if(MM_Size==1&&PG_Size==1&&num_of_process==1)
	{	
		textField.setText("10");
		txtArea.append("\n All of the process can fit into memory");
		return 10;
	}
	
	if(MM_Size==1&&PG_Size==1&&num_of_process==2)
	{	textField.setText("9");	return 9;	}
	
	if(MM_Size==1&&PG_Size==1&&num_of_process==3)
	{	textField.setText("7");	 return 7;	}
	if(MM_Size==1&&PG_Size==1&&num_of_process==4)
	{	textField.setText("5");	return 5;	}
	if(MM_Size==1&&PG_Size==1&&num_of_process==5)
	{	textField.setText("4");	return 4;	}
	
	if(MM_Size==2&&PG_Size==1&&num_of_process==1)
	{	
		textField.setText("10");
		txtArea.append("\n All of the process can fit into memory");
		return 10;
	}
	
	if(MM_Size==2&&PG_Size==1&&num_of_process==2)
	{	textField.setText("10"); return 10;		}
	
	if(MM_Size==2&&PG_Size==1&&num_of_process==3)
	{	textField.setText("9");	return 9;	}
	if(MM_Size==2&&PG_Size==1&&num_of_process==4)
	{	textField.setText("8");	return 8;	}
	if(MM_Size==2&&PG_Size==1&&num_of_process==5)
	{	textField.setText("6");	return 6;	}
	
	if(MM_Size==3&&PG_Size==1&&num_of_process==1)
	{	
		textField.setText("10");
		txtArea.append("\n All of the process can fit into memory");
		return 10;
	}
	
	if(MM_Size==3&&PG_Size==1&&num_of_process==2)
	{	textField.setText("10");	return 10;	}
	
	if(MM_Size==3&&PG_Size==1&&num_of_process==3)
	{	textField.setText("10");	return 10;	}
	if(MM_Size==3&&PG_Size==1&&num_of_process==4)
	{	textField.setText("9");	return 9;	}
	if(MM_Size==3&&PG_Size==1&&num_of_process==5)
	{	textField.setText("7");	return 7;	}
	
	
	if(MM_Size==1&&PG_Size==2&&num_of_process==1)
	{	
		textField.setText("10");
		txtArea.append("\n All of the process can fit into memory");
		return 10;
	}
	
	if(MM_Size==1&&PG_Size==2&&num_of_process==2)
	{	textField.setText("8");	return 8;	}
	
	if(MM_Size==1&&PG_Size==2&&num_of_process==3)
	{	textField.setText("6");	return 6;	}
	if(MM_Size==1&&PG_Size==2&&num_of_process==4)
	{	textField.setText("3");	return 3;	}
	if(MM_Size==1&&PG_Size==2&&num_of_process==5)
	{	textField.setText("2");	return 2;	}
	
	if(MM_Size==2&&PG_Size==2&&num_of_process==1)
	{	
		textField.setText("10");
		txtArea.append("\n All of the process can fit into memory");
		return 10;
	}
	
	if(MM_Size==2&&PG_Size==2&&num_of_process==2)
	{	textField.setText("9");	return 9;	}
	
	if(MM_Size==2&&PG_Size==2&&num_of_process==3)
	{	textField.setText("7");	 return 7;	}
	if(MM_Size==2&&PG_Size==2&&num_of_process==4)
	{	textField.setText("5");	return 5;	}
	if(MM_Size==2&&PG_Size==2&&num_of_process==5)
	{	textField.setText("3");	return 3;	}
	
	if(MM_Size==3&&PG_Size==2&&num_of_process==1)
	{	
		textField.setText("10");
		txtArea.append("\n All of the process can fit into memory");
		return 10;
	}
	
	if(MM_Size==3&&PG_Size==2&&num_of_process==2)
	{	textField.setText("10"); return 10;		}
	
	if(MM_Size==3&&PG_Size==2&&num_of_process==3)
	{	textField.setText("9");	 return 9;	}
	if(MM_Size==3&&PG_Size==2&&num_of_process==4)
	{	textField.setText("7");	return 7;	}
	if(MM_Size==3&&PG_Size==2&&num_of_process==5)
	{	textField.setText("5");	return 5;	}
	return 0;
	
}

public void initialise(int num_of_frames_per_process, int num_of_process, JPanel mainMemory, JTextField p11,JTextField p12, JTextField p13, JTextField p14, JTextField p15, JTextField p16,	JTextField p17, JTextField p18, JTextField p19, JTextField p110,
		JTextField p21,JTextField p22, JTextField p23, JTextField p24, JTextField p25, JTextField p26,	JTextField p27, JTextField p28, JTextField p29, JTextField p210,
		JTextField p31,JTextField p32, JTextField p33, JTextField p34, JTextField p35, JTextField p36,	JTextField p37, JTextField p38, JTextField p39, JTextField p310,
		JTextField p41,JTextField p42, JTextField p43, JTextField p44, JTextField p45, JTextField p46,	JTextField p47, JTextField p48, JTextField p49, JTextField p410,
		JTextField p51,JTextField p52, JTextField p53, JTextField p54, JTextField p55, JTextField p56,	JTextField p57, JTextField p58, JTextField p59, JTextField p510,JTextArea textArea) {
	
	// TODO Auto-generated method stub
	
	AnimationClass ac = new AnimationClass();
	if(num_of_frames_per_process==10)
	{
		if(num_of_process==1)
		{
			Rectangle rv1 = p11.getBounds();
			mainMemory.add(p11);
			ac.jTextFieldXLeft(rv1.x, 219, 3,1, p11);
			ac.jTextFieldYDown(rv1.y, 76, 3, 1, p11);
			
			Rectangle rv2 = p12.getBounds();
			mainMemory.add(p12);
			ac.jTextFieldXLeft(rv2.x, 314, 3,1, p12);
			ac.jTextFieldYDown(rv2.y, 76, 3, 1, p12);
			
			Rectangle rv3 = p13.getBounds();
			mainMemory.add(p13);
			ac.jTextFieldXLeft(rv3.x, 409, 3,1, p13);
			ac.jTextFieldYDown(rv3.y, 76, 3, 1, p13);
			
			Rectangle rv4 = p14.getBounds();
			mainMemory.add(p14);
			ac.jTextFieldXLeft(rv4.x, 504, 3,1, p14);
			ac.jTextFieldYDown(rv4.y, 76, 3, 1, p14);
			
			Rectangle rv5 = p15.getBounds();
			mainMemory.add(p15);
			ac.jTextFieldXLeft(rv5.x, 599, 3,1, p15);
			ac.jTextFieldYDown(rv5.y, 76, 3, 1, p15);
			
			Rectangle rv6 = p16.getBounds();
			mainMemory.add(p16);
			ac.jTextFieldXLeft(rv6.x, 219, 3,1, p16);
			ac.jTextFieldYDown(rv6.y, 130, 3, 1, p16);
			
			Rectangle rv7 = p17.getBounds();
			mainMemory.add(p17);
			ac.jTextFieldXLeft(rv7.x, 314, 3,1, p17);
			ac.jTextFieldYDown(rv7.y, 130, 3, 1, p17);
			
			Rectangle rv8 = p18.getBounds();
			mainMemory.add(p18);
			ac.jTextFieldXLeft(rv8.x, 409, 3,1, p18);
			ac.jTextFieldYDown(rv8.y, 130, 3, 1, p18);
			
			Rectangle rv9 = p19.getBounds();
			mainMemory.add(p19);
			ac.jTextFieldXLeft(rv9.x, 504, 3,1, p19);
			ac.jTextFieldYDown(rv9.y, 130, 3, 1, p19);
			
			Rectangle rv10 = p110.getBounds();
			mainMemory.add(p110);
			ac.jTextFieldXLeft(rv10.x, 599, 3,1, p110);
			ac.jTextFieldYDown(rv10.y, 130, 3, 1, p110);
			textArea.append("\n All of the Process is fit in to memory. No need for paging");	

		}
		if(num_of_process==2)
		{
			Rectangle rv1 = p11.getBounds();
			mainMemory.add(p11);
			ac.jTextFieldXLeft(rv1.x, 205, 3,1, p11);
			ac.jTextFieldYDown(rv1.y, 24, 3, 1, p11);
			
			Rectangle rv2 = p12.getBounds();
			mainMemory.add(p12);
			ac.jTextFieldXLeft(rv2.x, 300, 3,1, p12);
			ac.jTextFieldYDown(rv2.y, 24, 3, 1, p12);
			
			Rectangle rv3 = p13.getBounds();
			mainMemory.add(p13);
			ac.jTextFieldXLeft(rv3.x, 395, 3,1, p13);
			ac.jTextFieldYDown(rv3.y, 24, 3, 1, p13);
			
			Rectangle rv4 = p14.getBounds();
			mainMemory.add(p14);
			ac.jTextFieldXLeft(rv4.x, 490, 3,1, p14);
			ac.jTextFieldYDown(rv4.y, 24, 3, 1, p14);
			
			Rectangle rv5 = p15.getBounds();
			mainMemory.add(p15);
			ac.jTextFieldXLeft(rv5.x, 585, 3,1, p15);
			ac.jTextFieldYDown(rv5.y, 24, 3, 1, p15);
			
			Rectangle rv6 = p16.getBounds();
			mainMemory.add(p16);
			ac.jTextFieldXLeft(rv6.x, 205, 3,1, p16);
			ac.jTextFieldYDown(rv6.y, 70, 3, 1, p16);
			
			Rectangle rv7 = p17.getBounds();
			mainMemory.add(p17);
			ac.jTextFieldXLeft(rv7.x, 300, 3,1, p17);
			ac.jTextFieldYDown(rv7.y, 70, 3, 1, p17);
			
			Rectangle rv8 = p18.getBounds();
			mainMemory.add(p18);
			ac.jTextFieldXLeft(rv8.x, 395, 3,1, p18);
			ac.jTextFieldYDown(rv8.y, 70, 3, 1, p18);
			
			Rectangle rv9 = p19.getBounds();
			mainMemory.add(p19);
			ac.jTextFieldXLeft(rv9.x, 490, 3,1, p19);
			ac.jTextFieldYDown(rv9.y, 70, 3, 1, p19);
			
			Rectangle rv10 = p110.getBounds();
			mainMemory.add(p110);
			ac.jTextFieldXLeft(rv10.x, 585, 3,1, p110);
			ac.jTextFieldYDown(rv10.y, 70, 3, 1, p110);
			textArea.append("\n All of the Process is fit in to memory. No need for paging");
			
			 rv1 = p21.getBounds();
			mainMemory.add(p21);
			ac.jTextFieldXLeft(rv1.x, 205, 3,1, p21);
			ac.jTextFieldYDown(rv1.y, 116, 3, 1, p21);
			
			 rv2 = p22.getBounds();
			mainMemory.add(p22);
			ac.jTextFieldXLeft(rv2.x, 300, 3,1, p22);
			ac.jTextFieldYDown(rv2.y, 116, 3, 1, p22);
			
			 rv3 = p23.getBounds();
			mainMemory.add(p23);
			ac.jTextFieldXLeft(rv3.x, 395, 3,1, p23);
			ac.jTextFieldYDown(rv3.y, 116, 3, 1, p23);
			
			 rv4 = p24.getBounds();
			mainMemory.add(p24);
			ac.jTextFieldXLeft(rv4.x, 490, 3,1, p24);
			ac.jTextFieldYDown(rv4.y, 116, 3, 1, p24);
			
			 rv5 = p25.getBounds();
			mainMemory.add(p25);
			ac.jTextFieldXLeft(rv5.x, 585, 3,1, p25);
			ac.jTextFieldYDown(rv5.y, 116, 3, 1, p25);
			
			 rv6 = p26.getBounds();
			mainMemory.add(p26);
			ac.jTextFieldXLeft(rv6.x, 205, 3,1, p26);
			ac.jTextFieldYDown(rv6.y, 170, 3, 1, p26);
			
			 rv7 = p27.getBounds();
			mainMemory.add(p27);
			ac.jTextFieldXLeft(rv7.x, 300, 3,1, p27);
			ac.jTextFieldYDown(rv7.y, 170, 3, 1, p27);
			
			 rv8 = p28.getBounds();
			mainMemory.add(p28);
			ac.jTextFieldXLeft(rv8.x, 395, 3,1, p28);
			ac.jTextFieldYDown(rv8.y, 170, 3, 1, p28);
			
			 rv9 = p29.getBounds();
			mainMemory.add(p29);
			ac.jTextFieldXLeft(rv9.x, 490, 3,1, p29);
			ac.jTextFieldYDown(rv9.y, 170, 3, 1, p29);
			
			 rv10 = p210.getBounds();
			mainMemory.add(p210);
			ac.jTextFieldXLeft(rv10.x, 585, 3,1, p210);
			ac.jTextFieldYDown(rv10.y, 170, 3, 1, p210);
			textArea.append("\n All of the Process is fit in to memory. No need for paging");
			
			

		}
		if(num_of_process==3)
		{
			/*AnimationClass ac1 = new AnimationClass();
			Rectangle rv1 = p11.getBounds();
			mainMemory.add(p11);
			ac1.jTextFieldXLeft(rv1.x, 205, 3,1, p11);
			ac1.jTextFieldYDown(rv1.y, 23, 3, 1, p11);
			
			Rectangle rv2 = p12.getBounds();
			mainMemory.add(p12);
			ac1.jTextFieldXLeft(rv2.x, 300, 3,1, p12);
			ac1.jTextFieldYDown(rv2.y, 23, 3, 1, p12);
			
			Rectangle rv3 = p13.getBounds();
			mainMemory.add(p13);
			ac1.jTextFieldXLeft(rv3.x, 395, 3,1, p13);
			ac1.jTextFieldYDown(rv3.y, 23, 3, 1, p13);
			
			Rectangle rv4 = p14.getBounds();
			mainMemory.add(p14);
			ac1.jTextFieldXLeft(rv4.x, 490, 3,1, p14);
			ac.jTextFieldYDown(rv4.y, 23, 3, 1, p14);
			
			Rectangle rv5 = p15.getBounds();
			mainMemory.add(p15);
			ac.jTextFieldXLeft(rv5.x, 585, 3,1, p15);
			ac.jTextFieldYDown(rv5.y, 23, 3, 1, p15);
			
			Rectangle rv6 = p16.getBounds();
			mainMemory.add(p16);
			ac1.jTextFieldXLeft(rv6.x, 205, 3,1, p16);
			ac1.jTextFieldYDown(rv6.y, 58, 3, 1, p16);
			
			Rectangle rv7 = p17.getBounds();
			mainMemory.add(p17);
			ac1.jTextFieldXLeft(rv7.x, 300, 3,1, p17);
			ac1.jTextFieldYDown(rv7.y, 58, 3, 1, p17);
			
			Rectangle rv8 = p18.getBounds();
			mainMemory.add(p18);
			ac1.jTextFieldXLeft(rv8.x, 395, 3,1, p18);
			ac1.jTextFieldYDown(rv8.y, 58, 3, 1, p18);
			
			Rectangle rv9 = p19.getBounds();
			mainMemory.add(p19);
			ac1.jTextFieldXLeft(rv9.x, 490, 3,1, p19);
			ac1.jTextFieldYDown(rv9.y, 58, 3, 1, p19);
			
			Rectangle rv10 = p110.getBounds();
			mainMemory.add(p110);
			ac1.jTextFieldXLeft(rv10.x, 585, 3,1, p110);
			ac1.jTextFieldYDown(rv10.y, 58, 3, 1, p110);
			textArea.append("\n All of the Process is fit in to memory. No need for paging");
			
			
			 rv1 = p21.getBounds();
			mainMemory.add(p21);
			ac.jTextFieldXLeft(rv1.x, 205, 3,1, p21);
			ac.jTextFieldYUp(rv1.y, 93, 3, 1, p21);
			
			 rv2 = p22.getBounds();
			mainMemory.add(p22);
			ac.jTextFieldXLeft(rv2.x, 300, 3,1, p22);
			ac.jTextFieldYUp(rv2.y, 93, 3, 1, p22);
			
			 rv3 = p23.getBounds();
			mainMemory.add(p23);
			ac.jTextFieldXLeft(rv3.x, 395, 3,1, p23);
			ac.jTextFieldYUp(rv3.y, 93, 3, 1, p23);
			
			 rv4 = p24.getBounds();
			mainMemory.add(p24);
			ac.jTextFieldXLeft(rv4.x, 490, 3,1, p24);
			ac.jTextFieldYUp(rv4.y, 93, 3, 1, p24);
			
			 rv5 = p25.getBounds();
			mainMemory.add(p25);
			ac.jTextFieldXLeft(rv5.x, 585, 3,1, p25);
			ac.jTextFieldYUp(rv5.y, 93, 3, 1, p25);
			
			 rv6 = p26.getBounds();
			mainMemory.add(p26);
			ac.jTextFieldXLeft(rv6.x, 205, 3,1, p26);
			ac.jTextFieldYUp(rv6.y, 128, 3, 1, p26);
			
			 rv7 = p27.getBounds();
			mainMemory.add(p27);
			ac.jTextFieldXLeft(rv7.x, 300, 3,1, p27);
			ac.jTextFieldYUp(rv7.y, 128, 3, 1, p27);
			
			 rv8 = p28.getBounds();
			mainMemory.add(p28);
			ac.jTextFieldXLeft(rv8.x, 395, 3,1, p28);
			ac.jTextFieldYUp(rv8.y, 128, 3, 1, p28);
			
			 rv9 = p29.getBounds();
			mainMemory.add(p29);
			ac.jTextFieldXLeft(rv9.x, 490, 3,1, p29);
			ac.jTextFieldYUp(rv9.y, 128, 3, 1, p29);
			
			 rv10 = p210.getBounds();
			mainMemory.add(p210);
			ac.jTextFieldXLeft(rv10.x, 585, 3,1, p210);
			ac.jTextFieldYUp(rv10.y, 128, 3, 1, p210);
			textArea.append("\n All of the Process is fit in to memory. No need for paging");
			
			
			AnimationClass ac3 = new AnimationClass();
			rv1 = p31.getBounds();
			mainMemory.add(p31);
			ac.jTextFieldXLeft(rv1.x, 205, 3,1, p31);
			ac.jTextFieldYUp(rv1.y, 162, 3, 1, p31);
			
			 rv2 = p32.getBounds();
			mainMemory.add(p32);
			ac.jTextFieldXLeft(rv2.x, 300, 3,1, p32);
			ac.jTextFieldYUp(rv2.y, 162, 3, 1, p32);
			
			 rv3 = p33.getBounds();
			mainMemory.add(p33);
			ac.jTextFieldXLeft(rv3.x, 395, 3,1, p33);
			ac.jTextFieldYUp(rv3.y, 162, 3, 1, p33);
			
			 rv4 = p34.getBounds();
			mainMemory.add(p34);
			ac.jTextFieldXLeft(rv4.x, 490, 3,1, p34);
			ac.jTextFieldYUp(rv4.y, 162, 3, 1, p34);
			
			 rv5 = p35.getBounds();
			mainMemory.add(p35);
			ac.jTextFieldXLeft(rv5.x, 585, 3,1, p35);
			ac.jTextFieldYUp(rv5.y, 162, 3, 1, p35);
			
			 rv6 = p36.getBounds();
			mainMemory.add(p36);
			ac.jTextFieldXLeft(rv6.x, 205, 3,1, p36);
			ac.jTextFieldYUp(rv6.y, 197, 3, 1, p36);
			
			 rv7 = p37.getBounds();
			mainMemory.add(p37);
			ac.jTextFieldXLeft(rv7.x, 300, 3,1, p37);
			ac.jTextFieldYUp(rv7.y, 197, 3, 1, p37);
			
			 rv8 = p38.getBounds();
			mainMemory.add(p38);
			ac.jTextFieldXLeft(rv8.x, 395, 3,1, p38);
			ac.jTextFieldYUp(rv8.y, 197, 3, 1, p38);
			
			 rv9 = p39.getBounds();
			mainMemory.add(p39);
			ac.jTextFieldXLeft(rv9.x, 490, 3,1, p29);
			ac.jTextFieldYUp(rv9.y, 197, 3, 1, p29);
			
			 rv10 = p310.getBounds();
			mainMemory.add(p310);
			ac.jTextFieldXLeft(rv10.x, 585, 3,1, p310);
			ac.jTextFieldYUp(rv10.y, 197, 3, 1, p310);
			textArea.append("\n All of the Process is fit in to memory. No need for paging");*/
			
			JTextField Proc1 = new JTextField();
			mainMemory.add(Proc1);
			Proc1.setBounds(205, 23, 450, 50);
			Proc1.setText("ALL OF PROCESS 1");
			Proc1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
			Proc1.setHorizontalAlignment(SwingConstants.CENTER);
			Proc1.setBackground(Color.green);
			
			JTextField Proc2 = new JTextField();
			mainMemory.add(Proc2);
			Proc2.setBounds(205, 86, 450, 50);
			Proc2.setText("ALL OF PROCESS 2");
			Proc2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
			Proc2.setHorizontalAlignment(SwingConstants.CENTER);
			Proc2.setBackground(Color.green);
			
			JTextField Proc3 = new JTextField();
			mainMemory.add(Proc3);
			Proc3.setBounds(205, 149, 450, 50);
			Proc3.setText("ALL OF PROCESS 3");
			Proc3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
			Proc3.setHorizontalAlignment(SwingConstants.CENTER);
			Proc3.setBackground(Color.green);
			
			mainMemory.repaint();
		
			
			

		}
		
		
	}
	
	
	
	
}
	
	

}

