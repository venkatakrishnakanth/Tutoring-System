package PageReplacement;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import AppPackage.AnimationClass;

public class FIFO {
	static ArrayList<Integer> frameholder = new ArrayList<Integer>();
	static ArrayList<JTextField> frameholder1 = new ArrayList<JTextField>();
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private int correctpage;
	static int currentframe=0,pgfault=0,pagefault=0;
	public int[] Convert(String pageseq)
	{
		int[] converted = new int[pageseq.length()];
		for(int i=0; i<pageseq.length();i++)
		{
			converted[i]= Integer.parseInt(pageseq.substring(i, i+1));
		}
		return converted;
	}
	
public int framecheck(int l,int numberofframes, JTextField pgflt) {
		
		
			System.out.println("Number of frames in frameholder is "+frameholder.size());
			
			if (frameholder.contains(l)){
				System.out.println("Page already present in memory");				
				return 0;
				}
			else if(frameholder.size()<numberofframes){
				frameholder.add(l);
				System.out.println("moved page:"+l);
				pgfault++;
				pgflt.setText(Integer.toString(pgfault));
				return 1;}	
			else{
				System.out.println("Memory is full\nReplace a page using FIFO");
				pgfault++;
				pgflt.setText(Integer.toString(pgfault));
				
				return 2;
				
			}
			
		
		
	}


public int framecheck1(JTextField l,int numberofframes, JTextField pagflt) {
	
	
	System.out.println("Number of frames in frameholder is "+frameholder1.size());
	
	if (frameholder1.contains(l)){
		System.out.println("Page already present in memory");
		System.out.println("Framecheck returned 0");
		return 0;}
	else if(frameholder1.size()<numberofframes){
		frameholder1.add(l);
		System.out.println("moved page:"+l);
		pagefault++;
		pagflt.setText(Integer.toString(pagefault));
		return 1;}	
	else{
		System.out.println("Memory is full\nReplace a page using FIFO");
		pagefault++;
		pagflt.setText(Integer.toString(pagefault));
		
		return 2;
		
	}
	


}

public void move_into_memory(int l, JTextField[] page, JPanel panel) {
	AnimationClass ac = new AnimationClass();
	Rectangle rv = page[l].getBounds();	
	panel.add(page[l]);
	page[l].setBackground(Color.GREEN);
	int i = frameholder.size();
	ac.jTextFieldYUp(rv.y, 10, 20, 1, page[l]);
	ac.jTextFieldXLeft(rv.x, (12+i*50), 20, 1, page[l]);
	Rectangle r = page[l].getBounds();
	
}

public void move_into_memory1(JTextField page,JPanel panel) {
	AnimationClass ac = new AnimationClass();
	Rectangle rv = page.getBounds();	
	panel.add(page);
	page.setBackground(Color.GREEN);
	int i = frameholder1.size();
	ac.jTextFieldYUp(rv.y, 10, 20, 1, page);
	ac.jTextFieldXLeft(rv.x, (12+i*50), 20, 1, page);
	Rectangle r = page.getBounds();
	
}

public void replace_pagein_memory_fifo(int l, JTextField[] page, JPanel panel) {
	
	System.out.println("First value in frame holder before removing is"+frameholder.get(0));
	frameholder.add(l);
	AnimationClass ac = new AnimationClass();	
	page[frameholder.get(0)].setBackground(Color.RED);
	Rectangle rv = page[frameholder.get(0)].getBounds();
	Rectangle rv1 = page[l].getBounds();
	panel.add(page[l]);
	panel.remove(page[frameholder.get(0)]);
	frameholder.remove(frameholder.get(0));
	//panel.repaint(2000);
	System.out.println("First value in frame holder after removing is"+frameholder.get(0));
	page[l].setBackground(Color.GREEN);
	ac.jTextFieldYUp(rv1.y, rv.y, 20, 1, page[l]);
	ac.jTextFieldXLeft(rv1.x, rv.x, 20, 1, page[l]);	
	
}


public void replace_pagein_memory_fifo1( JTextField page, JPanel panel_12, JPanel panel_13) {
	
	System.out.println("First value in frame holder before removing is"+frameholder1.get(0));
	frameholder1.add(page);
	AnimationClass ac = new AnimationClass();
	JTextField a = frameholder1.get(0);
	Rectangle rv = frameholder1.get(0).getBounds();
	Rectangle rv1 = page.getBounds();
	panel_12.add(page);
	panel_13.repaint();
	Rectangle rr=gettingbounds(frameholder1.get(0));
	frameholder1.get(0).setBackground(Color.CYAN);
	panel_13.add(frameholder1.get(0));
	ac.jTextFieldYDown(frameholder1.get(0).getBounds().y, rr.y, 20, 1, frameholder1.get(0));
	ac.jTextFieldXRight(rv.x, rr.x, 20, 1, frameholder1.get(0));
	panel_13.repaint();
	panel_12.remove(frameholder1.get(0));
	frameholder1.remove(frameholder1.get(0));
	//System.out.println("First value in frame holder after removing is"+frameholder.get(0));
	page.setBackground(Color.GREEN);
	ac.jTextFieldYUp(rv1.y, rv.y, 20, 1, page);
	ac.jTextFieldXLeft(rv1.x, rv.x, 20, 1, page);	
	
}

public Rectangle gettingbounds(JTextField page_to_be_replaced){
	Rectangle rr = null;
	
	for(int i=0; i<frameholder1.size();i++){
		
		if(frameholder1.get(i)==page_to_be_replaced){
			
			Integer text = Integer.parseInt(page_to_be_replaced.getText());
			int x =12,y1 =13, y2 =122;
			if(text<5){
				 rr = new Rectangle(x+(text*130),y1,36,88);
				 System.out.println("Bound-> final pos where it has to move"+rr);
			}else{ rr = new Rectangle(x+((text-5)*130),y2,36,88);System.out.println("Bound-> final pos where it has to move"+rr);}
			
		}
	}
	return rr;
	
	
}


public void work(int numofpgs, String sequ, JPanel panel_12) {
	// TODO Auto-generated method stub
	
	
	int[] converted = Convert(sequ);
	if(currentframe<sequ.length())
	{
		int L = converted[currentframe];
		correctpage = L;
		currentframe++;
	}
}

public void movenext(String sequ){
	
	int[] converted = Convert(sequ);
	int L = converted[currentframe];
	System.out.print("CURRENT FRAME: "+currentframe);
	correctpage = L;
	currentframe++;
}

public void pages(JPanel panel_13,JPanel panel_12, int numofpgs,String sequ,JTextArea Fifo_happening, JTextField pagflt) {


	// TODO Auto-generated method stub

	// TODO Auto-generated method stub
	textField_1 = new JTextField();
	textField_1.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e) {
			
			if(correctpage == 0)
			{
				 int fc = framecheck1(textField_1,numofpgs,pagflt);
				 if(fc==1)
				 {
					 move_into_memory1(textField_1, panel_12);
					 panel_13.repaint();
					 movenext(sequ);
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page that has to be moved into memory is 0\n\n");
				 }else if (fc==2)
				 {
					 replace_pagein_memory_fifo1(textField_1, panel_12, panel_13);
					 movenext(sequ);
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 0\n\n");
				 }
				 else if (fc==0)
				 {
					 movenext(sequ);
				 }
			}else{
				Fifo_happening.setForeground(new Color(255,0,0));
				Fifo_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
			}
			
		}
	});
	textField_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
	textField_1.setBackground(new Color(0, 255, 255));
	textField_1.setHorizontalAlignment(SwingConstants.CENTER);
	textField_1.setText("0");
	textField_1.setBounds(12, 13, 36, 88);
	panel_13.add(textField_1);
	textField_1.setColumns(10);
	textField_1.setEditable(false);
	
	textField_2 = new JTextField();
	textField_2.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e1) {
			
			if(correctpage == 1)
			{
				 int fc = framecheck1(textField_2,numofpgs,pagflt);
				 if(fc==1)
				 {
					 move_into_memory1(textField_2, panel_12);
					 movenext(sequ);
					 panel_13.repaint();
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page that has to be moved into memory is 1\n\n");
				 }else if (fc==2)
				 {
					 replace_pagein_memory_fifo1(textField_2, panel_12,panel_13);
					 movenext(sequ);
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 1\n\n");
				 }
				 else if (fc==0)
				 {
					 movenext(sequ);
				 }
			}else{
				Fifo_happening.setForeground(new Color(255,0,0));
				Fifo_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
			}
			
		}
	});
	textField_2.setText("1");
	textField_2.setHorizontalAlignment(SwingConstants.CENTER);
	textField_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
	textField_2.setColumns(10);
	textField_2.setBackground(Color.CYAN);
	textField_2.setBounds(142, 13, 36, 88);
	panel_13.add(textField_2);
	textField_2.setEditable(false);
	
	textField_3 = new JTextField();
	
	textField_3.setText("2");
	textField_3.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e2) {
			
			if(correctpage == 2)
			{
				 int fc = framecheck1(textField_3,numofpgs,pagflt);
				 if(fc==1)
				 {
					 move_into_memory1(textField_3, panel_12);
					 movenext(sequ);
					 panel_13.repaint();
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page that has to be moved into memory is 2\n\n");
				 }else if (fc==2)
				 {
					 replace_pagein_memory_fifo1(textField_3, panel_12,panel_13);
					 movenext(sequ);
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 2\n\n");
				 }
				 else if (fc==0)
				 {
					 movenext(sequ);
				 }
			}else{
				Fifo_happening.setForeground(new Color(255,0,0));
				Fifo_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
			}
			
		}
	});
	textField_3.setHorizontalAlignment(SwingConstants.CENTER);
	textField_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
	textField_3.setColumns(10);
	textField_3.setBackground(Color.CYAN);
	textField_3.setBounds(272, 13, 36, 88);
	panel_13.add(textField_3);
	textField_3.setEditable(false);
	
	textField_4 = new JTextField();
	textField_4.setText("3");
	textField_4.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e3) {
			
			if(correctpage == 3)
			{
				 int fc = framecheck1(textField_4,numofpgs,pagflt);
				 if(fc==1)
				 {
					 move_into_memory1(textField_4, panel_12);
					 movenext(sequ);
					 panel_13.repaint();
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page that has to be moved into memory is 3\n\n");
				 }else if (fc==2)
				 {
					 replace_pagein_memory_fifo1(textField_4, panel_12,panel_13);
					 movenext(sequ);
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 3\n\n");
				 }
				 else if (fc==0)
				 {
					 movenext(sequ);
				 }
			}else{
				Fifo_happening.setForeground(new Color(255,0,0));
				Fifo_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
			}
			
		}
	});
	textField_4.setHorizontalAlignment(SwingConstants.CENTER);
	textField_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
	textField_4.setColumns(10);
	textField_4.setBackground(Color.CYAN);
	textField_4.setBounds(402, 13, 36, 88);
	panel_13.add(textField_4);
	textField_4.setEditable(false);
	
	textField_5 = new JTextField();
	textField_5.setText("4");
	textField_5.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e4) {
			
			if(correctpage == 4)
			{
				 int fc = framecheck1(textField_5,numofpgs,pagflt);
				 if(fc==1)
				 {
					 move_into_memory1(textField_5, panel_12);
					 movenext(sequ);
					 panel_13.repaint();
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page that has to be moved into memory is 4\n\n");
				 }else if (fc==2)
				 {
					 replace_pagein_memory_fifo1(textField_5, panel_12,panel_13);
					 movenext(sequ);
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 4\n\n");
				 }
				 else if (fc==0)
				 {
					 movenext(sequ);
				 }
			}else{
				Fifo_happening.setForeground(new Color(255,0,0));
				Fifo_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
			}
			
		}
	});
	textField_5.setHorizontalAlignment(SwingConstants.CENTER);
	textField_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
	textField_5.setColumns(10);
	textField_5.setBackground(Color.CYAN);
	textField_5.setBounds(532, 13, 36, 88);
	panel_13.add(textField_5);
	textField_5.setEditable(false);
	
	textField_6 = new JTextField();
	textField_6.setText("5");
	textField_6.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e5) {
			
			if(correctpage == 5)
			{
				 int fc = framecheck1(textField_6,numofpgs,pagflt);
				 if(fc==1)
				 {
					 move_into_memory1(textField_6, panel_12);
					 movenext(sequ);
					 panel_13.repaint();
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page that has to be moved into memory is 5\n\n");
				 }else if (fc==2)
				 {
					 replace_pagein_memory_fifo1(textField_6, panel_12, panel_13);
					 movenext(sequ);
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 5\n\n");
				 }
				 else if (fc==0)
				 {
					 movenext(sequ);
				 }
			}else{
				Fifo_happening.setForeground(new Color(255,0,0));
				Fifo_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
			}
			
		}
	});
	textField_6.setHorizontalAlignment(SwingConstants.CENTER);
	textField_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
	textField_6.setColumns(10);
	textField_6.setBackground(Color.CYAN);
	textField_6.setBounds(12, 122, 36, 88);
	panel_13.add(textField_6);
	textField_6.setEditable(false);
	
	textField_7 = new JTextField();
	textField_7.setText("6");
	textField_7.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e6) {
			
			if(correctpage == 6)
			{
				 int fc = framecheck1(textField_7,numofpgs,pagflt);
				 if(fc==1)
				 {
					 move_into_memory1(textField_7, panel_12);
					 movenext(sequ);
					 panel_13.repaint();
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page that has to be moved into memory is 6\n\n");
				 }else if (fc==2)
				 {
					 replace_pagein_memory_fifo1(textField_7, panel_12, panel_13);
					 movenext(sequ);
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 6\n\n");
				 }
				 else if (fc==0)
				 {
					 movenext(sequ);
				 }
			}else{
				Fifo_happening.setForeground(new Color(255,0,0));
				Fifo_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
			}
			
		}
	});
	textField_7.setHorizontalAlignment(SwingConstants.CENTER);
	textField_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
	textField_7.setColumns(10);
	textField_7.setBackground(Color.CYAN);
	textField_7.setBounds(142, 122, 36, 88);
	panel_13.add(textField_7);
	textField_7.setEditable(false);
	
	textField_8 = new JTextField();
	textField_8.setText("7");
	textField_8.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e7) {
			
			if(correctpage == 7)
			{
				 int fc = framecheck1(textField_8,numofpgs,pagflt);
				 if(fc==1)
				 {
					 move_into_memory1(textField_8, panel_12);
					 movenext(sequ);
					 panel_13.repaint();
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page that has to be moved into memory is 7\n\n");
				 }else if (fc==2)
				 {
					 replace_pagein_memory_fifo1(textField_8, panel_12, panel_13);
					 movenext(sequ);
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 7\n\n");
				 }
				 else if (fc==0)
				 {
					 movenext(sequ);
				 }
			}else{
				Fifo_happening.setForeground(new Color(255,0,0));
				Fifo_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
			}
			
		}
	});
	textField_8.setHorizontalAlignment(SwingConstants.CENTER);
	textField_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
	textField_8.setColumns(10);
	textField_8.setBackground(Color.CYAN);
	textField_8.setBounds(272, 122, 36, 88);
	panel_13.add(textField_8);
	textField_8.setEditable(false);
	
	textField_9 = new JTextField();
	textField_9.setText("8");
	textField_9.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e8) {
			
			if(correctpage == 8)
			{
				 int fc = framecheck1(textField_9,numofpgs,pagflt);
				 if(fc==1)
				 {
					 move_into_memory1(textField_9, panel_12);
					 movenext(sequ);
					 panel_13.repaint();
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page that has to be moved into memory is 8\n\n");
				 }else if (fc==2)
				 {
					 replace_pagein_memory_fifo1(textField_9, panel_12, panel_13);
					 movenext(sequ);
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 8\n\n");
				 }
				 else if (fc==0)
				 {
					 movenext(sequ);
				 }
			}else{
				Fifo_happening.setForeground(new Color(255,0,0));
				Fifo_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
			}
			
		}
	});
	textField_9.setHorizontalAlignment(SwingConstants.CENTER);
	textField_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
	textField_9.setColumns(10);
	textField_9.setBackground(Color.CYAN);
	textField_9.setBounds(402, 122, 36, 88);
	panel_13.add(textField_9);
	textField_9.setEditable(false);
	
	textField_10 = new JTextField();
	textField_10.setText("9");
	textField_10.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e1) {
			
			if(correctpage == 9)
			{
				 int fc = framecheck1(textField_10,numofpgs,pagflt);
				 if(fc==1)
				 {
					 move_into_memory1(textField_10, panel_12);
					 movenext(sequ);
					 panel_13.repaint();
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page that has to be moved into memory is 9\n\n");
				 }else if (fc==2)
				 {
					 replace_pagein_memory_fifo1(textField_10, panel_12, panel_13);
					 movenext(sequ);
					 Fifo_happening.setForeground(new Color(0, 0, 255));
					 Fifo_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 9\n\n");
				 }
				 else if (fc==0)
				 {
					 movenext(sequ);
				 }
			}else{
				Fifo_happening.setForeground(new Color(255,0,0));
				Fifo_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
			}
			
		}
	});
	textField_10.setHorizontalAlignment(SwingConstants.CENTER);
	textField_10.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
	textField_10.setColumns(10);
	textField_10.setBackground(Color.CYAN);
	textField_10.setBounds(532, 122, 36, 88);
	textField_10.setEditable(false);
	panel_13.add(textField_10);
	
	

}

}
