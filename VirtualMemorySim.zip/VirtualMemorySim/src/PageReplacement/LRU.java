package PageReplacement;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import AppPackage.AnimationClass;

public class LRU {
	
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private int correctpage;
	
	static ArrayList<Integer> frameholder_lru = new ArrayList<Integer>();
	static int currentframe_lru=0,pgfault_lru=0,pagefault=0;
	static ArrayList<Integer> frameholder11 = new ArrayList<Integer>();
	static ArrayList<JTextField> frameholder1_lru = new ArrayList<JTextField>();

	public int[] Convert(String pageseq_lru) {

		
		int[] converted = new int[pageseq_lru.length()];
		for(int i=0; i<pageseq_lru.length();i++)
		{
			converted[i]= Integer.parseInt(pageseq_lru.substring(i, i+1));
		}
		return converted;
	
	}

	public int framecheck_lru(int l, int number_of_frames_lru, JTextField pgflt_lru) {

		if (frameholder_lru.contains(l)){
			System.out.println("Page already present in memory");				
			return 0;
			}
		else if(frameholder_lru.size()<number_of_frames_lru){
			frameholder_lru.add(l);
			System.out.println("moved page:"+l);
			pgfault_lru++;
			pgflt_lru.setText(Integer.toString(pgfault_lru));
			return 1;}	
		else{
			System.out.println("Memory is full\nReplace a page using lru");
			pgfault_lru++;
			pgflt_lru.setText(Integer.toString(pgfault_lru));
			
			return 2;
			
		}
	
	}
	
	
public int framecheck1_lru(JTextField l,int num,int numberofframes, JTextField pagflt) {
		
		
		System.out.println("Number of frames in frameholder is "+frameholder1_lru.size());
		
		if (frameholder1_lru.contains(l)){
			System.out.println("Page already present in memory");
			System.out.println("Framecheck returned 0");
			return 0;}
		else if(frameholder1_lru.size()<numberofframes){
			frameholder1_lru.add(l);
			frameholder11.add(num);
			System.out.println("moved page:"+l);
			pagefault++;
			pagflt.setText(Integer.toString(pagefault));
			return 1;}	
		else{
			System.out.println("Memory is full\nReplace a page using lru");
			pagefault++;
			pagflt.setText(Integer.toString(pagefault));
			
			return 2;
			
		}
}
	
	
	

	public void move_into_memory_lru(int l, JTextField[] page_lru, JPanel panel_24) {
		// TODO Auto-generated method stub
		AnimationClass ac = new AnimationClass();
		Rectangle rv = page_lru[l].getBounds();	
		panel_24.add(page_lru[l]);
		page_lru[l].setBackground(Color.GREEN);
		int i = frameholder_lru.size();
		ac.jTextFieldYUp(rv.y, 10, 20, 1, page_lru[l]);
		ac.jTextFieldXLeft(rv.x, (12+i*50), 20, 1, page_lru[l]);
		Rectangle r = page_lru[l].getBounds();
		
	}
	
	public void move_into_memory1_lru(JTextField page,JPanel panel) {
		AnimationClass ac = new AnimationClass();
		Rectangle rv = page.getBounds();	
		panel.add(page);
		page.setBackground(Color.GREEN);
		int i = frameholder1_lru.size();
		ac.jTextFieldYUp(rv.y, 10, 20, 1, page);
		ac.jTextFieldXLeft(rv.x, (12+i*50), 20, 1, page);
		Rectangle r = page.getBounds();
	}
	
	
	

	public void replace_page_in_memory_lru(int l, JTextField[] page_lru, JPanel panel_24, int currentframe_lru2,
			int[] converted_lru) {
		// TODO Auto-generated method stub
		
		 int numberofframesinmemory = frameholder_lru.size();
		 int[] framesinmemory = new int[frameholder_lru.size()];
		 
		 for(int i=0; i<numberofframesinmemory; i++)
		 {
			 
			 int k=0;
			 int L = frameholder_lru.get(i);
			 for(k=0;k<currentframe_lru2;k++)
			 {
				 if(converted_lru[k]== L)
				 {
					 
					 framesinmemory[i]= k;
					
				 }		 
				 
					 
			 }
		 }
		 
		 for(int i=0;i<framesinmemory.length;i++)
		 {
			 System.out.println("framesinmemory["+framesinmemory[i]+"]");
		 }
		 int r=converted_lru.length;
		 int replacingframe=0;
		 
		 for(int v =0; v<framesinmemory.length;v++)
		 {
			if (framesinmemory[v]<r)
			{
				r = framesinmemory[v];
				replacingframe = v;
			}
				
		 }
		 
		 frameholder_lru.add(l);
		 AnimationClass ac = new AnimationClass();	
		 page_lru[frameholder_lru.get(replacingframe)].setBackground(Color.RED);
		 Rectangle rv = page_lru[frameholder_lru.get(replacingframe)].getBounds();
		 Rectangle rv1 = page_lru[l].getBounds();
		 panel_24.add(page_lru[l]);
		 panel_24.remove(page_lru[frameholder_lru.get(replacingframe)]);
		 frameholder_lru.remove(frameholder_lru.get(replacingframe));
		 page_lru[l].setBackground(Color.GREEN);
		 ac.jTextFieldYUp(rv1.y, rv.y, 20, 1, page_lru[l]);
		 ac.jTextFieldXLeft(rv1.x, rv.x, 20, 1, page_lru[l]);	
		
	}
	
	
	
 public void replace_pagein_memory_lru( JTextField page, JPanel panel_27, JPanel panel_28, int[] seq, int currentframe_lru2, int a,String sequ) {
		 
		 
		 int numberofframesinmemory = frameholder11.size();
		 int[] framesinmemory = new int[frameholder11.size()];
		 int[] converted_lru = Convert(sequ);
		 System.out.println("Sequence: "+ sequ);
		 for(int my=0;my<seq.length;my++)
			 System.out.println(converted_lru[my]);
		 
		 
		 for(int i=0; i<numberofframesinmemory; i++)
		 {
			 System.out.println("frameholder11["+i+"]: "+frameholder11.get(i));
			 int k=0;
			 int L = frameholder11.get(i);
			 for(k=0;k<currentframe_lru2;k++)
			 {
				 if(converted_lru[k]== L)
				 {
					 
					 framesinmemory[i]= k;
					
				 }		 
				 
					 
			 }
		 }
		 
		 for(int i=0;i<framesinmemory.length;i++)
		 {
			 System.out.println("framesinmemory["+framesinmemory[i]+"]");
		 }
		 int r=seq.length;
		 int replacingframe1=0;
		 
		 for(int v =0; v<framesinmemory.length;v++)
		 {
			if (framesinmemory[v]<r)
			{
				r = framesinmemory[v];
				replacingframe1 = v;
			}
				
		 }
		 System.out.println("replacing frame: "+ replacingframe1);
		 
		 frameholder1_lru.add(page);
		 frameholder11.add(a);
		 System.out.println("Added number is:"+ frameholder11.get(frameholder11.size()-1));
		 AnimationClass ac = new AnimationClass();
		 System.out.println("replacing frame: "+replacingframe1);
		 Rectangle rv = frameholder1_lru.get(replacingframe1).getBounds();
		 Rectangle rv1 = page.getBounds();
		 panel_27.add(page);
		 panel_28.repaint();
		 Rectangle rr=gettingbounds(frameholder1_lru.get(replacingframe1));
		 frameholder1_lru.get(replacingframe1).setBackground(Color.CYAN);
		 panel_28.add(frameholder1_lru.get(replacingframe1));
		 ac.jTextFieldYDown(frameholder1_lru.get(replacingframe1).getBounds().y, rr.y, 20, 1, frameholder1_lru.get(replacingframe1));
		 ac.jTextFieldXRight(rv.x, rr.x, 20, 1, frameholder1_lru.get(replacingframe1));
		 panel_28.repaint();
		 panel_27.remove(frameholder1_lru.get(replacingframe1));
		 frameholder1_lru.remove(frameholder1_lru.get(replacingframe1));
		 frameholder11.remove(replacingframe1);
			//System.out.println("First value in frame holder after removing is"+frameholder.get(0));
		 page.setBackground(Color.GREEN);
		 ac.jTextFieldYUp(rv1.y, rv.y, 20, 1, page);
		 ac.jTextFieldXLeft(rv1.x, rv.x, 20, 1, page);	
		 
		 
		 
		 
	 }
	
	 public Rectangle gettingbounds(JTextField page_to_be_replaced){
			Rectangle rr = null;
			
			for(int i=0; i<frameholder1_lru.size();i++){
				
				if(frameholder1_lru.get(i)==page_to_be_replaced){
					
					Integer text = Integer.parseInt(page_to_be_replaced.getText());
					int x =12,y1 =13, y2 =122;
					if(text<5){
						 rr = new Rectangle(x+(text*130),y1,36,88);
						 System.out.println("Bound-> final pos where it has to move"+rr);
					}else{ rr = new Rectangle(x+((text-5)*130),y2,36,88);System.out.println("Bound-> final pos where it has to move"+rr);}
					
				}
			}
			return rr;
			
			
		}
	
	
	
	
	
	
	 public void movenext_lru(String sequ){
			
			int[] converted = Convert(sequ);
			int L = converted[currentframe_lru];
			System.out.print("CURRENT FRAME: "+currentframe_lru);
			correctpage = L;
			currentframe_lru++;
		}
	 
	 
	 public void work(int numofpgs, String sequ, JPanel panel_27) {
			// TODO Auto-generated method stub
			
			
			int[] converted = Convert(sequ);
			if(currentframe_lru<sequ.length())
			{
				int L = converted[currentframe_lru];
				correctpage = L;
				currentframe_lru++;
			}
		}
	
	
	
	

	public void pages(JPanel panel_28, JPanel panel_27, int numofpgs, String sequ, JTextArea lru_happening,
			JTextField pagflt_lru, int[] seq) {
		
		
		textField_1 = new JTextField();
		textField_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if(correctpage == 0)
				{
					 int fc = framecheck1_lru(textField_1,0,numofpgs,pagflt_lru);
					 if(fc==1)
					 {
						 move_into_memory1_lru(textField_1, panel_27);
						 panel_28.repaint();
						 movenext_lru(sequ);
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page that has to be moved into memory is 0\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_lru(textField_1, panel_27, panel_28,seq,currentframe_lru,0,sequ);
						 movenext_lru(sequ);
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 0\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_lru(sequ);
					 }
				}else{
					lru_happening.setForeground(new Color(255,0,0));
					lru_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_1.setBackground(new Color(0, 255, 255));
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setText("0");
		textField_1.setBounds(12, 13, 36, 88);
		panel_28.add(textField_1);
		textField_1.setColumns(10);
		textField_1.setEditable(false);
		
		textField_2 = new JTextField();
		textField_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e1) {
				
				if(correctpage == 1)
				{
					 int fc = framecheck1_lru(textField_2,1,numofpgs,pagflt_lru);
					 if(fc==1)
					 {
						 move_into_memory1_lru(textField_2, panel_27);
						 movenext_lru(sequ);
						 panel_28.repaint();
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page that has to be moved into memory is 1\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_lru(textField_2, panel_27,panel_28,seq,currentframe_lru,1,sequ);
						 movenext_lru(sequ);
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 1\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_lru(sequ);
					 }
				}else{
					lru_happening.setForeground(new Color(255,0,0));
					lru_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_2.setText("1");
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_2.setColumns(10);
		textField_2.setBackground(Color.CYAN);
		textField_2.setBounds(142, 13, 36, 88);
		panel_28.add(textField_2);
		textField_2.setEditable(false);
		
		textField_3 = new JTextField();
		
		textField_3.setText("2");
		textField_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e2) {
				
				if(correctpage == 2)
				{
					 int fc = framecheck1_lru(textField_3,2,numofpgs,pagflt_lru);
					 if(fc==1)
					 {
						 move_into_memory1_lru(textField_3, panel_27);
						 movenext_lru(sequ);
						 panel_28.repaint();
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page that has to be moved into memory is 2\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_lru(textField_3, panel_27,panel_28,seq,currentframe_lru,2,sequ);
						 movenext_lru(sequ);
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 2\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_lru(sequ);
					 }
				}else{
					lru_happening.setForeground(new Color(255,0,0));
					lru_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		textField_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_3.setColumns(10);
		textField_3.setBackground(Color.CYAN);
		textField_3.setBounds(272, 13, 36, 88);
		panel_28.add(textField_3);
		textField_3.setEditable(false);
		
		textField_4 = new JTextField();
		textField_4.setText("3");
		textField_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e3) {
				
				if(correctpage == 3)
				{
					 int fc = framecheck1_lru(textField_4,3,numofpgs,pagflt_lru);
					 if(fc==1)
					 {
						 move_into_memory1_lru(textField_4, panel_27);
						 movenext_lru(sequ);
						 panel_28.repaint();
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page that has to be moved into memory is 3\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_lru(textField_4, panel_27,panel_28,seq,currentframe_lru,3,sequ);
						 movenext_lru(sequ);
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 3\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_lru(sequ);
					 }
				}else{
					lru_happening.setForeground(new Color(255,0,0));
					lru_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_4.setColumns(10);
		textField_4.setBackground(Color.CYAN);
		textField_4.setBounds(402, 13, 36, 88);
		panel_28.add(textField_4);
		textField_4.setEditable(false);
		
		textField_5 = new JTextField();
		textField_5.setText("4");
		textField_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e4) {
				
				if(correctpage == 4)
				{
					 int fc = framecheck1_lru(textField_5,4,numofpgs,pagflt_lru);
					 if(fc==1)
					 {
						 move_into_memory1_lru(textField_5, panel_27);
						 movenext_lru(sequ);
						 panel_28.repaint();
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page that has to be moved into memory is 4\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_lru(textField_5, panel_27,panel_28,seq,currentframe_lru,4,sequ);
						 movenext_lru(sequ);
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 4\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_lru(sequ);
					 }
				}else{
					lru_happening.setForeground(new Color(255,0,0));
					lru_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_5.setHorizontalAlignment(SwingConstants.CENTER);
		textField_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_5.setColumns(10);
		textField_5.setBackground(Color.CYAN);
		textField_5.setBounds(532, 13, 36, 88);
		panel_28.add(textField_5);
		textField_5.setEditable(false);
		
		textField_6 = new JTextField();
		textField_6.setText("5");
		textField_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e5) {
				
				if(correctpage == 5)
				{
					 int fc = framecheck1_lru(textField_6,5,numofpgs,pagflt_lru);
					 if(fc==1)
					 {
						 move_into_memory1_lru(textField_6, panel_27);
						 movenext_lru(sequ);
						 panel_28.repaint();
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page that has to be moved into memory is 5\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_lru(textField_6, panel_27, panel_28,seq,currentframe_lru,5,sequ);
						 movenext_lru(sequ);
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 5\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_lru(sequ);
					 }
				}else{
					lru_happening.setForeground(new Color(255,0,0));
					lru_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_6.setHorizontalAlignment(SwingConstants.CENTER);
		textField_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_6.setColumns(10);
		textField_6.setBackground(Color.CYAN);
		textField_6.setBounds(12, 122, 36, 88);
		panel_28.add(textField_6);
		textField_6.setEditable(false);
		
		textField_7 = new JTextField();
		textField_7.setText("6");
		textField_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e6) {
				
				if(correctpage == 6)
				{
					 int fc = framecheck1_lru(textField_7,6,numofpgs,pagflt_lru);
					 if(fc==1)
					 {
						 move_into_memory1_lru(textField_7, panel_27);
						 movenext_lru(sequ);
						 panel_28.repaint();
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page that has to be moved into memory is 6\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_lru(textField_7, panel_27, panel_28,seq,currentframe_lru,6,sequ);
						 movenext_lru(sequ);
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 6\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_lru(sequ);
					 }
				}else{
					lru_happening.setForeground(new Color(255,0,0));
					lru_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_7.setHorizontalAlignment(SwingConstants.CENTER);
		textField_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_7.setColumns(10);
		textField_7.setBackground(Color.CYAN);
		textField_7.setBounds(142, 122, 36, 88);
		panel_28.add(textField_7);
		textField_7.setEditable(false);
		
		textField_8 = new JTextField();
		textField_8.setText("7");
		textField_8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e7) {
				
				if(correctpage == 7)
				{
					 int fc = framecheck1_lru(textField_8,7,numofpgs,pagflt_lru);
					 if(fc==1)
					 {
						 move_into_memory1_lru(textField_8, panel_27);
						 movenext_lru(sequ);
						 panel_28.repaint();
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page that has to be moved into memory is 7\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_lru(textField_8, panel_27, panel_28,seq,currentframe_lru,7,sequ);
						 movenext_lru(sequ);
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 7\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_lru(sequ);
					 }
				}else{
					lru_happening.setForeground(new Color(255,0,0));
					lru_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_8.setHorizontalAlignment(SwingConstants.CENTER);
		textField_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_8.setColumns(10);
		textField_8.setBackground(Color.CYAN);
		textField_8.setBounds(272, 122, 36, 88);
		panel_28.add(textField_8);
		textField_8.setEditable(false);
		
		textField_9 = new JTextField();
		textField_9.setText("8");
		textField_9.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e8) {
				
				if(correctpage == 8)
				{
					 int fc = framecheck1_lru(textField_9,8,numofpgs,pagflt_lru);
					 if(fc==1)
					 {
						 move_into_memory1_lru(textField_9, panel_27);
						 movenext_lru(sequ);
						 panel_28.repaint();
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page that has to be moved into memory is 8\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_lru(textField_9, panel_27, panel_28,seq,currentframe_lru,8,sequ);
						 movenext_lru(sequ);
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 8\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_lru(sequ);
					 }
				}else{
					lru_happening.setForeground(new Color(255,0,0));
					lru_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_9.setHorizontalAlignment(SwingConstants.CENTER);
		textField_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_9.setColumns(10);
		textField_9.setBackground(Color.CYAN);
		textField_9.setBounds(402, 122, 36, 88);
		panel_28.add(textField_9);
		textField_9.setEditable(false);
		
		textField_10 = new JTextField();
		textField_10.setText("9");
		textField_10.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e1) {
				
				if(correctpage == 9)
				{
					 int fc = framecheck1_lru(textField_10,9,numofpgs,pagflt_lru);
					 if(fc==1)
					 {
						 move_into_memory1_lru(textField_10, panel_27);
						 movenext_lru(sequ);
						 panel_28.repaint();
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page that has to be moved into memory is 9\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_lru(textField_10, panel_27, panel_28,seq,currentframe_lru,9,sequ);
						 movenext_lru(sequ);
						 lru_happening.setForeground(new Color(0, 0, 255));
						 lru_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 9\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_lru(sequ);
					 }
				}else{
					lru_happening.setForeground(new Color(255,0,0));
					lru_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_10.setHorizontalAlignment(SwingConstants.CENTER);
		textField_10.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_10.setColumns(10);
		textField_10.setBackground(Color.CYAN);
		textField_10.setBounds(532, 122, 36, 88);
		textField_10.setEditable(false);
		panel_28.add(textField_10);
		
		


		
	
		
	}












}






