package PageReplacement;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import AppPackage.AnimationClass;

public class MFU {
	
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private int correctpage;
	
	static ArrayList<Integer> frameholder_mfu = new ArrayList<Integer>();
	static int currentframe_mfu=0,pgfault_mfu=0,pagefault=0;
	static ArrayList<Integer> frameholder11 = new ArrayList<Integer>();
	static ArrayList<JTextField> frameholder1_mfu = new ArrayList<JTextField>();

	public int[] Convert(String pageseq_mfu) {

		
		int[] converted = new int[pageseq_mfu.length()];
		for(int i=0; i<pageseq_mfu.length();i++)
		{
			converted[i]= Integer.parseInt(pageseq_mfu.substring(i, i+1));
		}
		return converted;
	
	}

	public int framecheck_mfu(int l, int number_of_frames_mfu, JTextField pgflt_mfu) {

		if (frameholder_mfu.contains(l)){
			System.out.println("Page already present in memory");				
			return 0;
			}
		else if(frameholder_mfu.size()<number_of_frames_mfu){
			frameholder_mfu.add(l);
			System.out.println("moved page:"+l);
			pgfault_mfu++;
			pgflt_mfu.setText(Integer.toString(pgfault_mfu));
			return 1;}	
		else{
			System.out.println("Memory is full\nReplace a page using mfu");
			pgfault_mfu++;
			pgflt_mfu.setText(Integer.toString(pgfault_mfu));
			
			return 2;
			
		}
	
	}
	
	
	
	public int framecheck1_mfu(JTextField l,int num,int numberofframes, JTextField pagflt) {
		
		
		System.out.println("Number of frames in frameholder is "+frameholder1_mfu.size());
		
		if (frameholder1_mfu.contains(l)){
			System.out.println("Page already present in memory");
			System.out.println("Framecheck returned 0");
			return 0;}
		else if(frameholder1_mfu.size()<numberofframes){
			frameholder1_mfu.add(l);
			frameholder11.add(num);
			System.out.println("moved page:"+l);
			pagefault++;
			pagflt.setText(Integer.toString(pagefault));
			return 1;}	
		else{
			System.out.println("Memory is full\nReplace a page using mfu");
			pagefault++;
			pagflt.setText(Integer.toString(pagefault));
			
			return 2;
			
		}
	}
	

	public void move_into_memory_mfu(int l, JTextField[] page_mfu, JPanel panel_32) {
		// TODO Auto-generated method stub
		AnimationClass ac = new AnimationClass();
		Rectangle rv = page_mfu[l].getBounds();	
		panel_32.add(page_mfu[l]);
		page_mfu[l].setBackground(Color.GREEN);
		int i = frameholder_mfu.size();
		ac.jTextFieldYUp(rv.y, 10, 20, 1, page_mfu[l]);
		ac.jTextFieldXLeft(rv.x, (12+i*50), 20, 1, page_mfu[l]);
		Rectangle r = page_mfu[l].getBounds();
		
	}
	
	
	
	public void move_into_memory1_mfu(JTextField page,JPanel panel) {
		AnimationClass ac = new AnimationClass();
		Rectangle rv = page.getBounds();	
		panel.add(page);
		page.setBackground(Color.GREEN);
		int i = frameholder1_mfu.size();
		ac.jTextFieldYUp(rv.y, 10, 20, 1, page);
		ac.jTextFieldXLeft(rv.x, (12+i*50), 20, 1, page);
		Rectangle r = page.getBounds();
	}
	
	

	public void replace_page_in_memory_mfu(int l, JTextField[] page_mfu, JPanel panel_32, int currentframe_mfu2,
			int[] converted_mfu) {
		// TODO Auto-generated method stub
		
		 int numberofframesinmemory = frameholder_mfu.size();
		 int[] framesinmemory = new int[frameholder_mfu.size()];
		 
		 for(int i=0; i<numberofframesinmemory; i++)
		 {
			 framesinmemory[i]=1;
			 int numoftimesused=0;
			 int k=0;
			 int L = frameholder_mfu.get(i);
			 for(k=0;k<currentframe_mfu2;k++)
			 {
				 if(converted_mfu[k]== L)
				 {
					 numoftimesused++;
					 framesinmemory[i]= numoftimesused;
					
				 }		 
				 
					 
			 }
		 }
		 
		 for(int i=0;i<framesinmemory.length;i++)
		 {
			 System.out.println("framesinmemory["+framesinmemory[i]+"]");
		 }
		 int r=0;
		 int replacingframe=0;
		 
		 for(int v =0; v<framesinmemory.length;v++)
		 {
			if (framesinmemory[v]>r)
			{
				r = framesinmemory[v];
				replacingframe = v;
			}
				
		 }
		 
		 frameholder_mfu.add(l);
		 AnimationClass ac = new AnimationClass();	
		 page_mfu[frameholder_mfu.get(replacingframe)].setBackground(Color.RED);
		 Rectangle rv = page_mfu[frameholder_mfu.get(replacingframe)].getBounds();
		 Rectangle rv1 = page_mfu[l].getBounds();
		 panel_32.add(page_mfu[l]);
		 panel_32.remove(page_mfu[frameholder_mfu.get(replacingframe)]);
		 frameholder_mfu.remove(frameholder_mfu.get(replacingframe));
		 page_mfu[l].setBackground(Color.GREEN);
		 ac.jTextFieldYUp(rv1.y, rv.y, 20, 1, page_mfu[l]);
		 ac.jTextFieldXLeft(rv1.x, rv.x, 20, 1, page_mfu[l]);	
		
	}
	
	
	
	public void replace_pagein_memory_mfu( JTextField page, JPanel panel_35, JPanel panel_36, int[] seq, int currentframe_mfu2, int a,String sequ) {
		 
		 
		 int numberofframesinmemory = frameholder11.size();
		 int[] framesinmemory = new int[frameholder11.size()];
		 int[] converted_mfu = Convert(sequ);
		 System.out.println("Sequence: "+ sequ);
		 for(int my=0;my<seq.length;my++)
			 System.out.println(converted_mfu[my]);
		 
		 
		 for(int i=0; i<numberofframesinmemory; i++)
		 {
			 System.out.println("frameholder11["+i+"]: "+frameholder11.get(i));
			 framesinmemory[i]=1;
			 int k=0;
			 int L = frameholder11.get(i);
			 int numoftimesused=0;
			 for(k=0;k<currentframe_mfu2;k++)
			 {
				 if(converted_mfu[k]== L)
				 {
					 numoftimesused++;
					 framesinmemory[i]= numoftimesused;
					
				 }		 
				 
					 
			 }
		 }
		 
		 for(int i=0;i<framesinmemory.length;i++)
		 {
			 System.out.println("framesinmemory["+framesinmemory[i]+"]");
		 }
		 int r=0;
		 int replacingframe1=0;
		 
		 for(int v =0; v<framesinmemory.length;v++)
		 {
			if (framesinmemory[v]>r)
			{
				r = framesinmemory[v];
				replacingframe1 = v;
			}
				
		 }
		 System.out.println("replacing frame: "+ replacingframe1);
		 
		 frameholder1_mfu.add(page);
		 frameholder11.add(a);
		 System.out.println("Added number is:"+ frameholder11.get(frameholder11.size()-1));
		 AnimationClass ac = new AnimationClass();
		 System.out.println("replacing frame: "+replacingframe1);
		 Rectangle rv = frameholder1_mfu.get(replacingframe1).getBounds();
		 Rectangle rv1 = page.getBounds();
		 panel_35.add(page);
		 panel_36.repaint();
		 Rectangle rr=gettingbounds(frameholder1_mfu.get(replacingframe1));
		 frameholder1_mfu.get(replacingframe1).setBackground(Color.CYAN);
		 panel_36.add(frameholder1_mfu.get(replacingframe1));
		 ac.jTextFieldYDown(frameholder1_mfu.get(replacingframe1).getBounds().y, rr.y, 20, 1, frameholder1_mfu.get(replacingframe1));
		 ac.jTextFieldXRight(rv.x, rr.x, 20, 1, frameholder1_mfu.get(replacingframe1));
		 panel_36.repaint();
		 panel_35.remove(frameholder1_mfu.get(replacingframe1));
		 frameholder1_mfu.remove(frameholder1_mfu.get(replacingframe1));
		 frameholder11.remove(replacingframe1);
			//System.out.println("First value in frame holder after removing is"+frameholder.get(0));
		 page.setBackground(Color.GREEN);
		 ac.jTextFieldYUp(rv1.y, rv.y, 20, 1, page);
		 ac.jTextFieldXLeft(rv1.x, rv.x, 20, 1, page);	
		 
		 
		 
		 
	 }
	
	 public Rectangle gettingbounds(JTextField page_to_be_replaced){
			Rectangle rr = null;
			
			for(int i=0; i<frameholder1_mfu.size();i++){
				
				if(frameholder1_mfu.get(i)==page_to_be_replaced){
					
					Integer text = Integer.parseInt(page_to_be_replaced.getText());
					int x =12,y1 =13, y2 =122;
					if(text<5){
						 rr = new Rectangle(x+(text*130),y1,36,88);
						 System.out.println("Bound-> final pos where it has to move"+rr);
					}else{ rr = new Rectangle(x+((text-5)*130),y2,36,88);System.out.println("Bound-> final pos where it has to move"+rr);}
					
				}
			}
			return rr;
			
			
		}
	
	
	
	
	
	 public void movenext_mfu(String sequ){
			
			int[] converted = Convert(sequ);
			int L = converted[currentframe_mfu];
			System.out.print("CURRENT FRAME: "+currentframe_mfu);
			correctpage = L;
			currentframe_mfu++;
		}
	 
	 
	 public void work(int numofpgs, String sequ, JPanel panel_35) {
			// TODO Auto-generated method stub
			
			
			int[] converted = Convert(sequ);
			if(currentframe_mfu<sequ.length())
			{
				int L = converted[currentframe_mfu];
				correctpage = L;
				currentframe_mfu++;
			}
		}

	public void pages(JPanel panel_36, JPanel panel_35, int numofpgs, String sequ, JTextArea mfu_happening,
			JTextField pagflt_mfu, int[] seq) {
		
		
		textField_1 = new JTextField();
		textField_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if(correctpage == 0)
				{
					 int fc = framecheck1_mfu(textField_1,0,numofpgs,pagflt_mfu);
					 if(fc==1)
					 {
						 move_into_memory1_mfu(textField_1, panel_35);
						 panel_36.repaint();
						 movenext_mfu(sequ);
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page that has to be moved into memory is 0\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_mfu(textField_1, panel_35, panel_36,seq,currentframe_mfu,0,sequ);
						 movenext_mfu(sequ);
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 0\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_mfu(sequ);
					 }
				}else{
					mfu_happening.setForeground(new Color(255,0,0));
					mfu_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_1.setBackground(new Color(0, 255, 255));
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setText("0");
		textField_1.setBounds(12, 13, 36, 88);
		panel_36.add(textField_1);
		textField_1.setColumns(10);
		textField_1.setEditable(false);
		
		textField_2 = new JTextField();
		textField_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e1) {
				
				if(correctpage == 1)
				{
					 int fc = framecheck1_mfu(textField_2,1,numofpgs,pagflt_mfu);
					 if(fc==1)
					 {
						 move_into_memory1_mfu(textField_2, panel_35);
						 movenext_mfu(sequ);
						 panel_36.repaint();
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page that has to be moved into memory is 1\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_mfu(textField_2, panel_35,panel_36,seq,currentframe_mfu,1,sequ);
						 movenext_mfu(sequ);
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 1\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_mfu(sequ);
					 }
				}else{
					mfu_happening.setForeground(new Color(255,0,0));
					mfu_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_2.setText("1");
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_2.setColumns(10);
		textField_2.setBackground(Color.CYAN);
		textField_2.setBounds(142, 13, 36, 88);
		panel_36.add(textField_2);
		textField_2.setEditable(false);
		
		textField_3 = new JTextField();
		
		textField_3.setText("2");
		textField_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e2) {
				
				if(correctpage == 2)
				{
					 int fc = framecheck1_mfu(textField_3,2,numofpgs,pagflt_mfu);
					 if(fc==1)
					 {
						 move_into_memory1_mfu(textField_3, panel_35);
						 movenext_mfu(sequ);
						 panel_36.repaint();
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page that has to be moved into memory is 2\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_mfu(textField_3, panel_35,panel_36,seq,currentframe_mfu,2,sequ);
						 movenext_mfu(sequ);
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 2\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_mfu(sequ);
					 }
				}else{
					mfu_happening.setForeground(new Color(255,0,0));
					mfu_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		textField_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_3.setColumns(10);
		textField_3.setBackground(Color.CYAN);
		textField_3.setBounds(272, 13, 36, 88);
		panel_36.add(textField_3);
		textField_3.setEditable(false);
		
		textField_4 = new JTextField();
		textField_4.setText("3");
		textField_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e3) {
				
				if(correctpage == 3)
				{
					 int fc = framecheck1_mfu(textField_4,3,numofpgs,pagflt_mfu);
					 if(fc==1)
					 {
						 move_into_memory1_mfu(textField_4, panel_35);
						 movenext_mfu(sequ);
						 panel_36.repaint();
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page that has to be moved into memory is 3\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_mfu(textField_4, panel_35,panel_36,seq,currentframe_mfu,3,sequ);
						 movenext_mfu(sequ);
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 3\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_mfu(sequ);
					 }
				}else{
					mfu_happening.setForeground(new Color(255,0,0));
					mfu_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_4.setColumns(10);
		textField_4.setBackground(Color.CYAN);
		textField_4.setBounds(402, 13, 36, 88);
		panel_36.add(textField_4);
		textField_4.setEditable(false);
		
		textField_5 = new JTextField();
		textField_5.setText("4");
		textField_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e4) {
				
				if(correctpage == 4)
				{
					 int fc = framecheck1_mfu(textField_5,4,numofpgs,pagflt_mfu);
					 if(fc==1)
					 {
						 move_into_memory1_mfu(textField_5, panel_35);
						 movenext_mfu(sequ);
						 panel_36.repaint();
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page that has to be moved into memory is 4\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_mfu(textField_5, panel_35,panel_36,seq,currentframe_mfu,4,sequ);
						 movenext_mfu(sequ);
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 4\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_mfu(sequ);
					 }
				}else{
					mfu_happening.setForeground(new Color(255,0,0));
					mfu_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_5.setHorizontalAlignment(SwingConstants.CENTER);
		textField_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_5.setColumns(10);
		textField_5.setBackground(Color.CYAN);
		textField_5.setBounds(532, 13, 36, 88);
		panel_36.add(textField_5);
		textField_5.setEditable(false);
		
		textField_6 = new JTextField();
		textField_6.setText("5");
		textField_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e5) {
				
				if(correctpage == 5)
				{
					 int fc = framecheck1_mfu(textField_6,5,numofpgs,pagflt_mfu);
					 if(fc==1)
					 {
						 move_into_memory1_mfu(textField_6, panel_35);
						 movenext_mfu(sequ);
						 panel_36.repaint();
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page that has to be moved into memory is 5\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_mfu(textField_6, panel_35, panel_36,seq,currentframe_mfu,5,sequ);
						 movenext_mfu(sequ);
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 5\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_mfu(sequ);
					 }
				}else{
					mfu_happening.setForeground(new Color(255,0,0));
					mfu_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_6.setHorizontalAlignment(SwingConstants.CENTER);
		textField_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_6.setColumns(10);
		textField_6.setBackground(Color.CYAN);
		textField_6.setBounds(12, 122, 36, 88);
		panel_36.add(textField_6);
		textField_6.setEditable(false);
		
		textField_7 = new JTextField();
		textField_7.setText("6");
		textField_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e6) {
				
				if(correctpage == 6)
				{
					 int fc = framecheck1_mfu(textField_7,6,numofpgs,pagflt_mfu);
					 if(fc==1)
					 {
						 move_into_memory1_mfu(textField_7, panel_35);
						 movenext_mfu(sequ);
						 panel_36.repaint();
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page that has to be moved into memory is 6\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_mfu(textField_7, panel_35, panel_36,seq,currentframe_mfu,6,sequ);
						 movenext_mfu(sequ);
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 6\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_mfu(sequ);
					 }
				}else{
					mfu_happening.setForeground(new Color(255,0,0));
					mfu_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_7.setHorizontalAlignment(SwingConstants.CENTER);
		textField_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_7.setColumns(10);
		textField_7.setBackground(Color.CYAN);
		textField_7.setBounds(142, 122, 36, 88);
		panel_36.add(textField_7);
		textField_7.setEditable(false);
		
		textField_8 = new JTextField();
		textField_8.setText("7");
		textField_8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e7) {
				
				if(correctpage == 7)
				{
					 int fc = framecheck1_mfu(textField_8,7,numofpgs,pagflt_mfu);
					 if(fc==1)
					 {
						 move_into_memory1_mfu(textField_8, panel_35);
						 movenext_mfu(sequ);
						 panel_36.repaint();
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page that has to be moved into memory is 7\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_mfu(textField_8, panel_35, panel_36,seq,currentframe_mfu,7,sequ);
						 movenext_mfu(sequ);
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 7\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_mfu(sequ);
					 }
				}else{
					mfu_happening.setForeground(new Color(255,0,0));
					mfu_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_8.setHorizontalAlignment(SwingConstants.CENTER);
		textField_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_8.setColumns(10);
		textField_8.setBackground(Color.CYAN);
		textField_8.setBounds(272, 122, 36, 88);
		panel_36.add(textField_8);
		textField_8.setEditable(false);
		
		textField_9 = new JTextField();
		textField_9.setText("8");
		textField_9.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e8) {
				
				if(correctpage == 8)
				{
					 int fc = framecheck1_mfu(textField_9,8,numofpgs,pagflt_mfu);
					 if(fc==1)
					 {
						 move_into_memory1_mfu(textField_9, panel_35);
						 movenext_mfu(sequ);
						 panel_36.repaint();
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page that has to be moved into memory is 8\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_mfu(textField_9, panel_35, panel_36,seq,currentframe_mfu,8,sequ);
						 movenext_mfu(sequ);
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 8\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_mfu(sequ);
					 }
				}else{
					mfu_happening.setForeground(new Color(255,0,0));
					mfu_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_9.setHorizontalAlignment(SwingConstants.CENTER);
		textField_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_9.setColumns(10);
		textField_9.setBackground(Color.CYAN);
		textField_9.setBounds(402, 122, 36, 88);
		panel_36.add(textField_9);
		textField_9.setEditable(false);
		
		textField_10 = new JTextField();
		textField_10.setText("9");
		textField_10.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e1) {
				
				if(correctpage == 9)
				{
					 int fc = framecheck1_mfu(textField_10,9,numofpgs,pagflt_mfu);
					 if(fc==1)
					 {
						 move_into_memory1_mfu(textField_10, panel_35);
						 movenext_mfu(sequ);
						 panel_36.repaint();
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page that has to be moved into memory is 9\n\n");
					 }else if (fc==2)
					 {
						 replace_pagein_memory_mfu(textField_10, panel_35, panel_36,seq,currentframe_mfu,9,sequ);
						 movenext_mfu(sequ);
						 mfu_happening.setForeground(new Color(0, 0, 255));
						 mfu_happening.append("\n -> That's Correct. The page in memory has to be replaced with page 9\n\n");
					 }
					 else if (fc==0)
					 {
						 movenext_mfu(sequ);
					 }
				}else{
					mfu_happening.setForeground(new Color(255,0,0));
					mfu_happening.append("\n -?? That's not right. The page that you should click should be: "+ correctpage+"\n\n");
				}
				
			}
		});
		textField_10.setHorizontalAlignment(SwingConstants.CENTER);
		textField_10.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_10.setColumns(10);
		textField_10.setBackground(Color.CYAN);
		textField_10.setBounds(532, 122, 36, 88);
		textField_10.setEditable(false);
		panel_36.add(textField_10);
		
		


		
	
		
	}
	
	

}
